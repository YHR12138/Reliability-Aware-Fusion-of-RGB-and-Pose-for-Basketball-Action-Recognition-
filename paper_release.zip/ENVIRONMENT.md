# Environment

The reported numbers were produced on a single laptop GPU with cached RGB
frames.

| component | version |
| --- | --- |
| OS | Windows 11 |
| Python | 3.12.10 |
| PyTorch | 2.14.1+cu126 |
| CUDA runtime | 12.6 |
| GPU | NVIDIA GeForce RTX 3060 Laptop, 6 GB |
| NumPy | 2.5.3 |
| OpenCV | 5.0.0 |
| Matplotlib | 3.11.2 |
| SciPy | 1.18.1 |
| Pillow | 12.3.0 |
| python-docx | 1.2.0 (paper build only) |

## Notes

* The RGB frame cache (`rgb_f8_s64.npy`, 4,096 × 8 × 64 × 64 × 3 uint8) is
  decoded once with the *same* procedure as the on-the-fly loader
  (`np.linspace` over the clip, BGR→RGB, `INTER_AREA` to 64×64), so it is
  numerically identical to decoding video every epoch.
* `workers=0` is intentional: it keeps the evaluation order fixed and makes
  the noise masks reproducible.
* CUDA kernels are not bit-deterministic across processes: rerunning the same
  configuration with the same seed can move Macro-F1 by up to ~0.02 on a
  single seed. The five-seed means are reported for this reason.
