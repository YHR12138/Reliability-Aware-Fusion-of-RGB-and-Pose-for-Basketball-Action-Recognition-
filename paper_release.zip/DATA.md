# Data and splits

## What is (and is not) redistributed

| asset | here | notes |
| --- | --- | --- |
| 6,144 raw videos | no | original MultiSubjects release |
| 17-joint pose pickles (`train.pkl`, `val.pkl`) | no | original MultiSubjects release |
| subject-disjoint clip manifest | **yes** (`manifests/`) | the split used in the paper |
| path-rewritten local manifest | **yes** | machine-specific paths; regenerate with `make_local_manifest.py` |
| RGB frame cache (8 × 64 × 64) | no | 384 MB, regenerate in ~10 min |
| trained checkpoints | Release asset | 30 × `best.pt` |
| metrics, logs, summaries, figures | **yes** (`results/`, `figures/`) | everything behind the tables |

## Split

| partition | clips | subjects |
| --- | --- | --- |
| train | 2,852 | 691 |
| validation | 625 | 149 |
| test | 619 | 148 |
| total | 4,096 | 988 |

Class counts over the 4,096 pose-annotated clips: Dribble 1,564 / Layup 512 /
Shoot 2,020. Inside the training partition: 1,081 / 352 / 1,419.

The official clip-level split leaks identities: the released training list
shares **614 subjects** with validation and **821 with test**. The manifest
here groups clips by subject id (parsed from `subject_action_trial.mp4`) before
assigning partitions, using a deterministic greedy assignment that keeps the
class ratios and partition sizes close to the original targets. An audit
script verifies that the subject sets are pairwise disjoint and that every clip
has a pose record.

Because the split is new, the numbers are **not comparable** with published
results on the official split; they are a lower, leak-free estimate.

## Rebuilding the manifest

```bash
python code/make_pose_manifest.py --help      # build the pose-level manifest
python code/local_run/make_local_manifest.py \
    --manifest manifests/manifest_pose_subject_disjoint.csv \
    --video-root /path/to/MultiSubjects_train_val_test \
    --out manifests/manifest_local.csv
```

The local manifest keeps `split`, `label`, `subject`, `frame_dir` and the pose
file of every clip and only rewrites `path`.

## Data statement (paste into the paper)

> The raw videos and the released 17-joint pose records are part of the
> MultiSubjects dataset (Han et al., CVIU 249, 104193, 2024) and are not
> redistributed. We release the exact subject-disjoint manifest, the training
> and evaluation code, all per-seed metrics and the trained checkpoints at
> <REPOSITORY_URL>. The split contains 2,852 / 625 / 619 clips from
> 691 / 149 / 148 subjects with no subject overlap across partitions.

## Attribution

MultiSubjects (also abbreviated *Henu-MultiSubjects* after the collecting
institution, Henan University) is the work of Z. Han, W. Qin, Y. Wang,
Q. Wang and Y. Shi, *Computer Vision and Image Understanding*, vol. 249,
Art. no. 104193, 2024. Please cite that paper, not this repository, whenever
the data itself is used. This repository only adds the subject-disjoint
manifest, the training/evaluation code and the result artifacts.

The example frames shown in Fig. 1 of the paper are crops from
Henu-MultiSubjects clips; they are reproduced for illustration only and are
not redistributed in this repository.
