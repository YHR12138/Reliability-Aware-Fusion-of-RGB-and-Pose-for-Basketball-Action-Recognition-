# Checkpoints

The 30 trained checkpoints (six rules × five seeds) are **not** stored in this
git repository. Download the release asset `checkpoints.zip` and unpack it so
the tree looks like:

```
checkpoints/
  final_ours_seed2026/best.pt
  final_ours_seed2027/best.pt
  ...
  final_fixed_seed2030/best.pt
```

Each `best.pt` is a `torch.save({"model": state_dict, "epoch": int,
"val_macro_f1": float})` produced by `run_multimodal_baseline.py`.

To rerun the robustness sweep without retraining:

```bash
python code/local_run/cached_runner.py --job robust --cache-dir cache \
    --manifest manifests/manifest_local.csv --pose-root /path/to/pose_data \
    --mode ours --checkpoint checkpoints/final_ours_seed2026/best.pt \
    --out outputs/robust_ours_seed2026 --batch-size 8 --frames 8 \
    --pose-frames 16 --size 64 --workers 0 --limit 0 --seed 2026
```

For `--mode fixed` add `--fixed-alpha 0.34`.
