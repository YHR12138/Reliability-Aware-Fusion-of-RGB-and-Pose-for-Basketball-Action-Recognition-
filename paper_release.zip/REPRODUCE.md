# Reproducing the paper

## 0. Environment

See [ENVIRONMENT.md](ENVIRONMENT.md). Python 3.12, PyTorch 2.14 (CUDA 12.6),
OpenCV, NumPy, Matplotlib.

## 1. Data

1. Download MultiSubjects / Henu-MultiSubjects (videos + pose pickles).
2. Rewrite the paths:

```bash
python code/local_run/make_local_manifest.py \
    --manifest manifests/manifest_pose_subject_disjoint.csv \
    --video-root /path/to/MultiSubjects_train_val_test \
    --out manifests/manifest_local.csv
```

3. Build the RGB cache once (this is what makes a training run take ~1.4 min):

```bash
python code/local_run/build_rgb_cache.py \
    --manifest manifests/manifest_local.csv \
    --out-dir cache --frames 8 --size 64 --workers 8
```

## 2. Train the six rules (five seeds)

```powershell
./code/scripts/run_training.ps1 `
    -Modes @('rgb','pose','sum','concat','ours','fixed') `
    -Seeds @(2026,2027,2028,2029,2030) -FixedAlpha 0.34 -ForceRerun
```

Each run writes `outputs/final_<mode>_seed<seed>/metrics.txt` and `best.pt`.

## 3. Robustness sweep (15 conditions × 4 rules × 5 seeds)

```powershell
./code/scripts/run_robust.ps1 `
    -Modes @('ours','sum','fixed','concat') `
    -Seeds @(2026,2027,2028,2029,2030) -FixedAlpha 0.34 -ForceRerun
```

Outputs `outputs/robust_<mode>_seed<seed>/metrics.tsv` (15 rows) and
`config.json`.

## 4. Summaries

```bash
python code/local_run/normalize_metrics.py --root .
python code/summarize_results.py --root .
```

This writes `reports/main_summary.csv`, `reports/robust_summary.csv` and the
per-seed raw tables.

## 5. Figures

```bash
python code/local_run/local_to_incoming.py --root . --out incoming_local
python code/local_run/gen_paper_figures.py --incoming incoming_local --out figures
```

* Fig. 1 (pipeline overview) is drawn by `code/local_run/make_fig1_v2.py`; the
  frames come from `code/local_run/make_fig1_frames.py` (which selects a frame
  without the burned-in surveillance clock). The camera-ready variant is kept
  as `figures/fig1_paper.png`.
* Fig. 2–6 are produced by `gen_paper_figures.py`.

## 6. Validation

```bash
python code/local_run/validate.py --root .
```

It checks the split sizes, that every checkpoint loads, and that the `clean`
row of each robustness run reproduces the corresponding `metrics.txt`.

## Expected runtime (single RTX 3060 Laptop, cached frames)

| step | per unit | total |
| --- | --- | --- |
| one training run (10 epochs) | ≈ 1.4 min | 30 runs ≈ 42 min |
| one robustness run (15 conditions) | ≈ 18 s | 20 runs ≈ 6 min |
| summaries + figures | — | ≈ 2 min |
