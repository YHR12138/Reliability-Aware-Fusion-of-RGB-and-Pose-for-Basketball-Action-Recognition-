import csv, json, statistics
from pathlib import Path
import argparse

ap=argparse.ArgumentParser(); ap.add_argument('--root', default=''); args=ap.parse_args()
root=Path(args.root) if args.root else Path(__file__).resolve().parent; out=root/'outputs'; reports=root/'reports'; reports.mkdir(exist_ok=True)
main=[]
for p in sorted(out.glob('final_*_seed*/metrics.txt')):
    text=p.read_text(encoding='utf-8'); row={'path':str(p)}
    for line in text.splitlines():
        if line.startswith('mode='): row['mode']=line.split('=',1)[1]
        elif line.startswith('test='):
            # metrics.txt stores test=(loss, accuracy, macro_f1, [f1_dribble, f1_layup, f1_shoot]).
            # The previous indexing started at the loss, which reported the loss as the
            # accuracy and the accuracy as the macro-F1.
            vals=line.split('=',1)[1].strip('()').split(','); row['loss']=float(vals[0]); row['accuracy']=float(vals[1]); row['macro_f1']=float(vals[2]); row['f1_dribble']=float(vals[3].strip(' []')); row['f1_layup']=float(vals[4]); row['f1_shoot']=float(vals[5].strip(' ]'))
    if 'mode' in row: row['seed']=p.parent.name.split('seed')[-1]; main.append(row)
with (reports/'main_raw.csv').open('w',newline='',encoding='utf-8-sig') as f:
    fields=['mode','seed','accuracy','macro_f1','f1_dribble','f1_layup','f1_shoot','loss','path']; w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(main)
summary=[]
for mode in sorted(set(r['mode'] for r in main)):
    rs=[r for r in main if r['mode']==mode]; row={'mode':mode,'n':len(rs)}
    for k in ['accuracy','macro_f1','f1_dribble','f1_layup','f1_shoot']:
        vals=[r[k] for r in rs];row[k+'_mean']=statistics.mean(vals);row[k+'_std']=statistics.stdev(vals) if len(vals)>1 else 0.0
    summary.append(row)
with (reports/'main_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
    fields=['mode','n','accuracy_mean','accuracy_std','macro_f1_mean','macro_f1_std','f1_dribble_mean','f1_dribble_std','f1_layup_mean','f1_layup_std','f1_shoot_mean','f1_shoot_std'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(summary)
robust=[]
for p in sorted(out.glob('robust_*_seed*/metrics.tsv')):
    with p.open(encoding='utf-8') as f:
        for r in csv.DictReader(f,delimiter='\t'): r['path']=str(p); r['seed']=p.parent.name.split('seed')[-1]; robust.append(r)
if robust:
    with (reports/'robust_raw.csv').open('w',newline='',encoding='utf-8-sig') as f:
        fields=list(robust[0]);w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(robust)
    grouped={}
    for r in robust:
        key=(r.get('mode',''),r.get('condition',''))
        grouped.setdefault(key,[]).append(r)
    rs=[]
    for (mode,condition), rows in sorted(grouped.items()):
        row={'mode':mode,'condition':condition,'n':len(rows)}
        for k in ['accuracy','macro_f1','f1_dribble','f1_layup','f1_shoot','delta_accuracy','delta_macro_f1']:
            vals=[float(x[k]) for x in rows if x.get(k,'') not in ('',None)]
            row[k+'_mean']=statistics.mean(vals) if vals else ''
            row[k+'_std']=statistics.stdev(vals) if len(vals)>1 else (0.0 if vals else '')
        rs.append(row)
    with (reports/'robust_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
        fields=['mode','condition','n','accuracy_mean','accuracy_std','macro_f1_mean','macro_f1_std','f1_dribble_mean','f1_dribble_std','f1_layup_mean','f1_layup_std','f1_shoot_mean','f1_shoot_std','delta_accuracy_mean','delta_accuracy_std','delta_macro_f1_mean','delta_macro_f1_std']
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rs)
print(json.dumps({'main_runs':len(main),'robust_rows':len(robust),'reports':str(reports)},ensure_ascii=False,indent=2))
