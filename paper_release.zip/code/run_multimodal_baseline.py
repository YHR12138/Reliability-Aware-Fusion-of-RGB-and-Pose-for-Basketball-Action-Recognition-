import argparse
import csv
import pickle
import random
from pathlib import Path

import cv2
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)


class MultiDataset(Dataset):
    def __init__(self, manifest, pose_root, split, frames=16, pose_frames=32, size=112, train=False, limit=0, use_rgb=True):
        with open(manifest, newline="", encoding="utf-8") as f:
            rows = [r for r in csv.DictReader(f) if r["split"] == split]
        self.rows = rows[:limit] if limit else rows
        self.frames, self.pose_frames, self.size, self.train, self.use_rgb = frames, pose_frames, size, train, use_rgb
        self.pose = {}
        for name in ("train.pkl", "val.pkl"):
            with open(Path(pose_root) / name, "rb") as f:
                for item in pickle.load(f):
                    self.pose[str(item["frame_dir"])] = item
        missing = [r["frame_dir"] for r in self.rows if r["frame_dir"] not in self.pose]
        if missing:
            raise RuntimeError(f"missing pose records: {missing[:3]}")

    def __len__(self): return len(self.rows)

    def _video(self, path):
        cap = cv2.VideoCapture(path)
        n = max(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), 1)
        ids = np.linspace(0, n - 1, self.frames).astype(np.int64)
        # Decode once in presentation order. Repeated random seeks are much slower
        # for the H.264 clips and leave the GPU idle during full-dataset training.
        wanted = {int(i) for i in ids}
        out = {}
        idx = 0
        while idx < n:
            ok, frame = cap.read()
            if not ok:
                break
            if idx in wanted:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                out[idx] = cv2.resize(frame, (self.size, self.size), interpolation=cv2.INTER_AREA)
            idx += 1
        cap.release()
        last = np.zeros((self.size, self.size, 3), np.uint8)
        frames = []
        for idx in ids:
            if int(idx) in out: last = out[int(idx)]
            frames.append(last.copy())
        x = np.stack(frames).astype(np.float32) / 255.0
        # Keep RGB and RGB-derived Pose geometrically aligned. The previous
        # RGB-only flip silently misaligned the two representations.
        x = torch.from_numpy(x).permute(0, 3, 1, 2)
        mean = torch.tensor([0.485, 0.456, 0.406])[None, :, None, None]
        std = torch.tensor([0.229, 0.224, 0.225])[None, :, None, None]
        return (x - mean) / std

    def _pose(self, item):
        xy = item["keypoint"][0].astype(np.float32)  # T,J,2
        score = item["keypoint_score"][0].astype(np.float32)
        h, w = item.get("img_shape", (1080, 2160))
        xy[..., 0] /= max(float(w), 1.0); xy[..., 1] /= max(float(h), 1.0)
        # Center and scale by the visible joint box, retaining a validity mask.
        valid = score >= 0.30
        if valid.any():
            pts = xy[valid]
            center = pts.mean(0); scale = max(float(np.ptp(pts[:, 0])), float(np.ptp(pts[:, 1])), 1e-3)
            xy = (xy - center) / scale
        ids = np.linspace(0, max(len(xy) - 1, 0), self.pose_frames).astype(np.int64)
        xy = xy[ids]; score = score[ids]
        quality = np.array([
            float((score >= 0.30).mean()),
            float((score < 0.30).all(axis=1).mean()),
            float((np.abs(xy) > 2.0).any(axis=2).mean()),
            float(np.median(np.linalg.norm(np.diff(xy, axis=0), axis=2))) if len(xy) > 1 else 0.0,
        ], dtype=np.float32)
        pose = torch.from_numpy(xy.reshape(self.pose_frames, -1)).float()
        return pose, torch.from_numpy(quality)

    def __getitem__(self, i):
        row = self.rows[i]
        x = self._video(row["path"]) if self.use_rgb else torch.zeros(self.frames, 3, self.size, self.size)
        p, q = self._pose(self.pose[row["frame_dir"]])
        return x, p, q, int(row["label"]), row["video"]


class RGBEncoder(nn.Module):
    def __init__(self, d=256):
        super().__init__()
        self.net = nn.Sequential(nn.Conv2d(3, 24, 5, 2, 2), nn.BatchNorm2d(24), nn.ReLU(),
                                 nn.Conv2d(24, 48, 3, 2, 1), nn.BatchNorm2d(48), nn.ReLU(),
                                 nn.Conv2d(48, 96, 3, 2, 1), nn.BatchNorm2d(96), nn.ReLU(),
                                 nn.Conv2d(96, 128, 3, 2, 1), nn.BatchNorm2d(128), nn.ReLU(),
                                 nn.AdaptiveAvgPool2d(1))
        self.fc = nn.Linear(128, d)
    def forward(self, x):
        b, t, c, h, w = x.shape
        z = self.net(x.reshape(b*t, c, h, w)).flatten(1).reshape(b, t, -1).mean(1)
        return self.fc(z)


class PoseEncoder(nn.Module):
    def __init__(self, d=256, in_dim=34):
        super().__init__()
        self.net = nn.Sequential(nn.Conv1d(in_dim, 128, 3, padding=1), nn.ReLU(),
                                 nn.Conv1d(128, 192, 3, padding=1), nn.ReLU())
        self.fc = nn.Linear(192, d)
    def forward(self, x):
        return self.fc(self.net(x.transpose(1, 2)).mean(-1))


# The "fixed" baseline used to be ``0.5 * hr + 0.5 * hp``, which is exactly the
# same function as the "sum" baseline (``0.5 * (hr + hp)``), so the two reported
# identical numbers everywhere.  It now takes a constant weight alpha that is
# selected on the validation split, which keeps the fusion rule fixed and
# input-independent while making it a genuinely separate baseline.
class FusionModel(nn.Module):
    def __init__(self, mode="ours", d=256, fixed_alpha=0.5):
        super().__init__(); self.mode = mode; self.fixed_alpha = float(fixed_alpha)
        self.rgb, self.pose = RGBEncoder(d), PoseEncoder(d)
        if mode == "concat": self.fuse = nn.Linear(2*d, d)
        if mode == "transformer":
            enc = nn.TransformerEncoderLayer(d_model=d, nhead=4, dim_feedforward=512, dropout=0.1, batch_first=True)
            self.fuse = nn.TransformerEncoder(enc, num_layers=2)
        if mode == "ours": self.gate = nn.Sequential(nn.Linear(2*d+4+2, 128), nn.ReLU(), nn.Linear(128, 1))
        self.cls = nn.Linear(d, 3)

    def forward(self, rgb, pose, quality, avail=None):
        hr, hp = self.rgb(rgb), self.pose(pose)
        if avail is None: avail = torch.ones((rgb.size(0), 2), device=rgb.device)
        if self.mode == "rgb": h = hr
        elif self.mode == "pose": h = hp
        elif self.mode == "sum": h = 0.5 * (hr + hp)
        elif self.mode == "concat": h = self.fuse(torch.cat([hr, hp], 1))
        elif self.mode == "transformer": h = self.fuse(torch.stack([hr, hp], 1)).mean(1)
        elif self.mode == "fixed":
            a = self.fixed_alpha
            h = a * hr + (1.0 - a) * hp
        else:
            g = torch.sigmoid(self.gate(torch.cat([hr, hp, quality, avail], 1)))
            h = g * hr + (1-g) * hp
        return self.cls(h)


def scores(y, p):
    y, p = np.asarray(y), np.asarray(p); f=[]
    for c in range(3):
        tp=((y==c)&(p==c)).sum(); fp=((y!=c)&(p==c)).sum(); fn=((y==c)&(p!=c)).sum()
        pr=tp/max(tp+fp,1); re=tp/max(tp+fn,1); f.append(2*pr*re/max(pr+re,1e-12))
    return float((y==p).mean()), float(np.mean(f)), f


def epoch(model, loader, device, criterion, opt=None, dropout=False):
    train = opt is not None; model.train(train); ys=[]; ps=[]; total=0
    for rgb, pose, q, y, _ in loader:
        rgb, pose, q, y = rgb.to(device), pose.to(device), q.to(device), y.to(device)
        avail = torch.ones((len(y),2), device=device)
        if train and dropout and model.mode in {"ours","sum","concat","transformer","fixed"}:
            r = torch.rand(len(y), device=device); avail[:,0] = (r >= 0.25).float(); avail[:,1] = (r < 0.75).float()
            rgb = rgb * avail[:,0,None,None,None,None]; pose = pose * avail[:,1,None,None]
        with torch.set_grad_enabled(train):
            logits=model(rgb,pose,q,avail); loss=criterion(logits,y)
            if train: opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
        total += loss.item()*len(y); ys.extend(y.detach().cpu().numpy()); ps.extend(logits.argmax(1).detach().cpu().numpy())
    return total/max(len(ys),1), *scores(ys,ps)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--manifest',required=True); ap.add_argument('--pose-root',required=True); ap.add_argument('--mode',default='ours',choices=['rgb','pose','sum','concat','transformer','ours','fixed']); ap.add_argument('--out',required=True); ap.add_argument('--epochs',type=int,default=1); ap.add_argument('--batch-size',type=int,default=8); ap.add_argument('--frames',type=int,default=16); ap.add_argument('--pose-frames',type=int,default=32); ap.add_argument('--size',type=int,default=112); ap.add_argument('--limit',type=int,default=0); ap.add_argument('--workers',type=int,default=4); ap.add_argument('--eval-only',action='store_true'); ap.add_argument('--seed',type=int,default=0); ap.add_argument('--fixed-alpha',type=float,default=0.5,help='constant RGB weight of the fixed-fusion baseline'); args=ap.parse_args()
    seed_all(args.seed); out=Path(args.out); out.mkdir(parents=True,exist_ok=True); device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    use_rgb = args.mode != 'pose'
    tr=MultiDataset(args.manifest,args.pose_root,'train',args.frames,args.pose_frames,args.size,True,args.limit,use_rgb); va=MultiDataset(args.manifest,args.pose_root,'val',args.frames,args.pose_frames,args.size,False,args.limit,use_rgb); te=MultiDataset(args.manifest,args.pose_root,'test',args.frames,args.pose_frames,args.size,False,args.limit,use_rgb)
    def loader(ds,shuffle):
        kwargs = dict(batch_size=args.batch_size, shuffle=shuffle, num_workers=args.workers,
                      pin_memory=True)
        if args.workers > 0:
            kwargs['persistent_workers'] = True
            kwargs['prefetch_factor'] = 2
        return DataLoader(ds, **kwargs)
    counts=np.bincount([int(r['label']) for r in tr.rows],minlength=3); wt=torch.tensor(counts.sum()/np.maximum(counts,1),dtype=torch.float32); wt/=wt.mean(); criterion=nn.CrossEntropyLoss(weight=wt.to(device))
    model=FusionModel(args.mode,fixed_alpha=args.fixed_alpha).to(device); opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-4); sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,args.epochs)
    print(f'device={device} mode={args.mode} train={len(tr)} val={len(va)} test={len(te)} counts={counts.tolist()}',flush=True)
    best=-1
    if not args.eval_only:
        for ep in range(1,args.epochs+1):
            a=epoch(model,loader(tr,True),device,criterion,opt,True); b=epoch(model,loader(va,False),device,criterion); sched.step(); print(f'epoch={ep} train={a} val={b}',flush=True)
            if b[2]>best: best=b[2]; torch.save({'model':model.state_dict(),'epoch':ep,'val_macro_f1':best},out/'best.pt')
    model.load_state_dict(torch.load(out/'best.pt',map_location=device)['model']); z=epoch(model,loader(te,False),device,criterion); print(f'test={z}',flush=True); (out/'metrics.txt').write_text(f'mode={args.mode}\ntrain={len(tr)} val={len(va)} test={len(te)}\ntest={z}\n',encoding='utf-8')


if __name__=='__main__': main()
