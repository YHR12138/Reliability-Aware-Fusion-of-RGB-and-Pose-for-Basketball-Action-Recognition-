"""Decode every manifest video once and cache the 8x64x64 RGB frames.

``MultiDataset._video`` pulls 8 uniformly spaced frames, converts BGR->RGB and
resizes to 64x64 with INTER_AREA.  That decode is by far the slowest part of the
pipeline and it is identical for every mode and every seed, so it is done once
here and reused by the cached dataset.  The cached tensor is bit-identical to
what ``_video`` would return, which keeps the fixed experimental protocol
unchanged while removing the repeated video decoding.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from pathlib import Path

import cv2
import numpy as np


def decode_one(job):
    frame_dir, path, frames, size = job
    cv2.setNumThreads(1)
    cap = cv2.VideoCapture(path)
    n = max(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), 1)
    ids = np.linspace(0, n - 1, frames).astype(np.int64)
    wanted = {int(i) for i in ids}
    seen = {}
    idx = 0
    while idx < n:
        ok, frame = cap.read()
        if not ok:
            break
        if idx in wanted:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            seen[idx] = cv2.resize(frame, (size, size), interpolation=cv2.INTER_AREA)
        idx += 1
    cap.release()
    last = np.zeros((size, size, 3), np.uint8)
    out = []
    for want in ids:
        if int(want) in seen:
            last = seen[int(want)]
        out.append(last.copy())
    return frame_dir, np.stack(out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True, type=Path)
    ap.add_argument("--out-dir", required=True, type=Path)
    ap.add_argument("--frames", type=int, default=8)
    ap.add_argument("--size", type=int, default=64)
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 4) // 2))
    ap.add_argument("--processes", action="store_true",
                    help="Use processes instead of threads (needs an unrestricted shell)")
    args = ap.parse_args()

    with args.manifest.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    jobs = [(r["frame_dir"], r["path"], args.frames, args.size) for r in rows]
    print(f"decoding {len(jobs)} videos with {args.workers} workers", flush=True)

    args.out_dir.mkdir(parents=True, exist_ok=True)
    frames_path = args.out_dir / f"rgb_f{args.frames}_s{args.size}.npy"
    array = np.lib.format.open_memmap(
        frames_path, mode="w+", dtype=np.uint8,
        shape=(len(jobs), args.frames, args.size, args.size, 3),
    )
    index: dict[str, int] = {}
    done = 0
    # OpenCV releases the GIL while decoding, so a thread pool parallelises the
    # decode without the inter-process overhead (and works under the sandbox).
    executor = ProcessPoolExecutor if args.processes else ThreadPoolExecutor
    with executor(max_workers=args.workers) as pool:
        for frame_dir, data in pool.map(decode_one, jobs, chunksize=8):
            array[done] = data
            index[frame_dir] = done
            done += 1
            if done % 128 == 0 or done == len(jobs):
                print(f"  {done}/{len(jobs)}", flush=True)
    array.flush()
    del array
    (args.out_dir / "rgb_index.json").write_text(
        json.dumps(index, ensure_ascii=False), encoding="utf-8")
    print(f"wrote {frames_path} ({frames_path.stat().st_size / 2**20:.0f} MiB) "
          f"with {len(index)} entries")


if __name__ == "__main__":
    main()
