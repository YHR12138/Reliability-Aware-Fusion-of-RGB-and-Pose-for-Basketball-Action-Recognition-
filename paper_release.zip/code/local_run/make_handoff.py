"""Write the hand-off/registration tables required by the manual (section 10).

It re-checks every directory against the acceptance rules (file presence, split
sizes, seed/mode consistency, number of robustness conditions) and marks each
row PASS or FAIL.  Nothing is copied or renamed.
"""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

import torch

MODES = ["rgb", "pose", "sum", "concat", "ours", "fixed"]
SEEDS = [2026, 2027, 2028]
EXPECTED_SPLIT = "train=2852 val=625 test=619"
# The fixed condition list in section 6 of the manual (clean + 4 RGB missing +
# 4 pose missing + 3 RGB noise + 3 pose jitter) and the implementation in
# robust_eval.py both give 15 conditions.  Section 7's checklist says 25, which
# contradicts both; the code and the explicit list are treated as authoritative.
EXPECTED_CONDITIONS = 15


def read_metrics(path: Path) -> dict:
    info = {"mode": "", "split_ok": False, "test_acc": "", "test_macro_f1": ""}
    text = path.read_text(encoding="utf-8")
    for line in text.splitlines():
        if line.startswith("mode="):
            info["mode"] = line.split("=", 1)[1]
        elif line.startswith("train="):
            info["split_ok"] = EXPECTED_SPLIT in line
        elif line.startswith("test="):
            values = line.split("=", 1)[1].strip().strip("()").split(",")
            # (loss, accuracy, macro_f1, [f1_dribble, f1_layup, f1_shoot])
            info["test_acc"] = float(values[1])
            info["test_macro_f1"] = float(values[2])
    return info


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    args = ap.parse_args()
    root = args.root
    outputs = root / "outputs"
    reports = root / "reports"
    reports.mkdir(exist_ok=True)

    main_rows = []
    for mode in MODES:
        for seed in SEEDS:
            out = outputs / f"final_{mode}_seed{seed}"
            best, metrics = out / "best.pt", out / "metrics.txt"
            row = {"mode": mode, "seed": seed, "output_dir": str(out),
                   "best_pt": str(best), "metrics_txt": str(metrics),
                   "train/val/test": "", "val_macro_f1": "", "test_macro_f1": "",
                   "status": "FAIL"}
            if best.exists() and metrics.exists():
                info = read_metrics(metrics)
                try:
                    state = torch.load(best, map_location="cpu", weights_only=False)
                    val_f1 = state.get("val_macro_f1", "")
                    epoch = state.get("epoch", "")
                except Exception as exc:  # pragma: no cover - defensive
                    row["notes"] = f"checkpoint unreadable: {exc}"
                    main_rows.append(row)
                    continue
                row.update({
                    "train/val/test": EXPECTED_SPLIT if info["split_ok"] else "MISMATCH",
                    "val_macro_f1": val_f1,
                    "test_macro_f1": info["test_macro_f1"],
                    "epoch": epoch,
                })
                ok = (info["split_ok"] and info["mode"] == mode
                      and isinstance(val_f1, float))
                row["status"] = "PASS" if ok else "FAIL"
            main_rows.append(row)

    fields = ["mode", "seed", "output_dir", "best_pt", "metrics_txt",
              "train/val/test", "epoch", "val_macro_f1", "test_macro_f1",
              "status", "notes"]
    with (reports / "handoff_main.tsv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter="\t", extrasaction="ignore")
        w.writeheader()
        w.writerows(main_rows)

    robust_rows = []
    # Section 6 of the manual scopes the robustness suite to these modes only
    # (concat "when time permits"); rgb/pose are intentionally out of scope.
    robust_modes = {"sum", "ours", "fixed", "concat"}
    for mode in MODES:
        for seed in SEEDS:
            ckpt_dir = outputs / f"final_{mode}_seed{seed}"
            out = outputs / f"robust_{mode}_seed{seed}"
            tsv = out / "metrics.tsv"
            count = ""
            row = {"mode": mode, "seed": seed, "checkpoint_dir": str(ckpt_dir),
                   "robust_dir": str(out), "condition_count": 0,
                   "metrics_tsv": str(tsv),
                   "status": "FAIL" if mode in robust_modes else "N/A"}
            if tsv.exists() and (ckpt_dir / "best.pt").exists():
                with tsv.open(encoding="utf-8") as f:
                    count = sum(1 for _ in csv.DictReader(f, delimiter="\t"))
                row["condition_count"] = count
                row["status"] = "PASS" if count == EXPECTED_CONDITIONS else "FAIL"
            robust_rows.append(row)

    with (reports / "handoff_robust.tsv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["mode", "seed", "checkpoint_dir",
                                          "robust_dir", "condition_count",
                                          "metrics_tsv", "status"],
                           delimiter="\t")
        w.writeheader()
        w.writerows(robust_rows)

    main_pass = sum(1 for r in main_rows if r["status"] == "PASS")
    robust_pass = sum(1 for r in robust_rows if r["status"] == "PASS")
    print(f"handoff_main.tsv: {main_pass}/{len(main_rows)} PASS")
    print(f"handoff_robust.tsv: {robust_pass}/{len(robust_rows)} PASS")
    for r in main_rows:
        if r["status"] != "PASS":
            print(f"  MAIN  {r['mode']:6s} seed={r['seed']} -> {r['status']}")
    for r in robust_rows:
        if r["status"] != "PASS":
            print(f"  ROBUST {r['mode']:6s} seed={r['seed']} -> {r['status']}")


if __name__ == "__main__":
    main()
