"""Cached-RGB drop-in replacement for ``MultiDataset``.

The class is API-compatible with ``run_multimodal_baseline.MultiDataset`` and
produces identical tensors; only the video decoding is served from the
pre-decoded cache instead of re-reading the mp4 files on every epoch.

Usage from a runner script::

    import cached_data; cached_data.install(cache_dir)
    import run_multimodal_baseline as R
    R.main()
"""

from __future__ import annotations

import csv
import json
import pickle
import sys
from pathlib import Path

import numpy as np
import torch

MEAN = torch.tensor([0.485, 0.456, 0.406])
STD = torch.tensor([0.229, 0.224, 0.225])


class CachedMultiDataset(torch.utils.data.Dataset):
    _cache_arrays: dict[Path, np.ndarray] = {}
    _cache_index: dict[Path, dict[str, int]] = {}

    def __init__(self, manifest, pose_root, split, frames=16, pose_frames=32,
                 size=112, train=False, limit=0, use_rgb=True, cache_dir=None):
        if cache_dir is None:
            raise RuntimeError("cache_dir is required for CachedMultiDataset")
        self.cache_dir = Path(cache_dir)
        with open(manifest, newline="", encoding="utf-8") as f:
            rows = [r for r in csv.DictReader(f) if r["split"] == split]
        self.rows = rows[:limit] if limit else rows
        self.frames, self.pose_frames, self.size = frames, pose_frames, size
        self.train, self.use_rgb = train, use_rgb
        self.pose = {}
        for name in ("train.pkl", "val.pkl"):
            with open(Path(pose_root) / name, "rb") as f:
                for item in pickle.load(f):
                    self.pose[str(item["frame_dir"])] = item
        missing = [r["frame_dir"] for r in self.rows if r["frame_dir"] not in self.pose]
        if missing:
            raise RuntimeError(f"missing pose records: {missing[:3]}")
        if self.use_rgb:
            key = self.cache_dir
            if key not in CachedMultiDataset._cache_arrays:
                frames_path = self.cache_dir / f"rgb_f{frames}_s{size}.npy"
                CachedMultiDataset._cache_arrays[key] = np.load(
                    frames_path, mmap_mode="r")
                CachedMultiDataset._cache_index[key] = json.loads(
                    (self.cache_dir / "rgb_index.json").read_text(encoding="utf-8"))
            self._frames = CachedMultiDataset._cache_arrays[key]
            self._index = CachedMultiDataset._cache_index[key]
            absent = [r["frame_dir"] for r in self.rows
                      if r["frame_dir"] not in self._index]
            if absent:
                raise RuntimeError(f"missing cached frames: {absent[:3]}")

    def __len__(self):
        return len(self.rows)

    def _video(self, frame_dir):
        raw = np.asarray(self._frames[self._index[frame_dir]])
        x = raw.astype(np.float32) / 255.0
        x = torch.from_numpy(x).permute(0, 3, 1, 2)
        return (x - MEAN[None, :, None, None]) / STD[None, :, None, None]

    # -- identical to run_multimodal_baseline.MultiDataset._pose --
    def _pose(self, item):
        xy = item["keypoint"][0].astype(np.float32)
        score = item["keypoint_score"][0].astype(np.float32)
        h, w = item.get("img_shape", (1080, 2160))
        xy[..., 0] /= max(float(w), 1.0)
        xy[..., 1] /= max(float(h), 1.0)
        valid = score >= 0.30
        if valid.any():
            pts = xy[valid]
            center = pts.mean(0)
            scale = max(float(np.ptp(pts[:, 0])), float(np.ptp(pts[:, 1])), 1e-3)
            xy = (xy - center) / scale
        ids = np.linspace(0, max(len(xy) - 1, 0), self.pose_frames).astype(np.int64)
        xy = xy[ids]
        score = score[ids]
        quality = np.array([
            float((score >= 0.30).mean()),
            float((score < 0.30).all(axis=1).mean()),
            float((np.abs(xy) > 2.0).any(axis=2).mean()),
            float(np.median(np.linalg.norm(np.diff(xy, axis=0), axis=2))) if len(xy) > 1 else 0.0,
        ], dtype=np.float32)
        pose = torch.from_numpy(xy.reshape(self.pose_frames, -1)).float()
        return pose, torch.from_numpy(quality)

    def __getitem__(self, i):
        row = self.rows[i]
        if self.use_rgb:
            x = self._video(row["frame_dir"])
        else:
            x = torch.zeros(self.frames, 3, self.size, self.size)
        p, q = self._pose(self.pose[row["frame_dir"]])
        return x, p, q, int(row["label"]), row["video"]


def install(cache_dir):
    """Patch the original modules so their ``MultiDataset`` uses the cache."""
    from functools import partial

    cache_dir = Path(cache_dir)
    factory = partial(CachedMultiDataset, cache_dir=cache_dir)
    import run_multimodal_baseline as baseline
    baseline.MultiDataset = factory
    for name in ("robust_eval",):
        module = sys.modules.get(name)
        if module is not None:
            module.MultiDataset = factory
    return factory
