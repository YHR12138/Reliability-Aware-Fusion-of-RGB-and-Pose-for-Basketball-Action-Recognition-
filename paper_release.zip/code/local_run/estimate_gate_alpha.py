"""Estimate a constant fusion weight from the trained confidence gates.

For every ``ours`` checkpoint the script runs the validation split and reports
the mean of g = sigma(MLP(z)).  That mean is a natural fixed weight for a
"frozen gate" baseline: it is chosen without touching the test split.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    ap.add_argument("--checkpoint-root", required=True, type=Path)
    ap.add_argument("--cache-dir", required=True, type=Path)
    ap.add_argument("--seeds", nargs="*", type=int, default=[2026, 2027, 2028])
    args = ap.parse_args()

    root = args.root.resolve()
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(root / "local_run"))
    import cached_data
    cached_data.install(args.cache_dir)
    from run_multimodal_baseline import FusionModel, MultiDataset

    dataset = MultiDataset(root / "local_run" / "manifest_local.csv",
                           root / "pose_data", "val", 8, 16, 64, False, 0, True)
    loader = DataLoader(dataset, batch_size=8, shuffle=False, num_workers=0)
    print(f"validation clips: {len(dataset)}")

    means = []
    for seed in args.seeds:
        path = args.checkpoint_root / f"final_ours_seed{seed}" / "best.pt"
        state = torch.load(path, map_location="cpu", weights_only=False)
        model = FusionModel("ours")
        model.load_state_dict(state["model"] if "model" in state else state)
        model.eval()
        gates = []
        with torch.no_grad():
            for rgb, pose, quality, _y, _name in loader:
                hr = model.rgb(rgb)
                hp = model.pose(pose)
                avail = torch.ones((len(hr), 2))
                gate = torch.sigmoid(
                    model.gate(torch.cat([hr, hp, quality, avail], 1)))
                gates.append(gate)
        gate = torch.cat(gates).numpy().ravel()
        means.append(float(gate.mean()))
        print(f"seed {seed}: mean g = {gate.mean():.4f} "
              f"(sd {gate.std():.4f}, "
              f"10-90% {np.percentile(gate, 10):.3f}-{np.percentile(gate, 90):.3f})")
    print(f"mean over seeds: {np.mean(means):.4f}")


if __name__ == "__main__":
    main()
