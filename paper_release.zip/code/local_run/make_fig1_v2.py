"""Draw Figure 1: two representation streams fused by a reliability-aware gate.

Coordinates are in units of 1/100 inch on a 720 x 300 canvas, i.e. 7.2 x 3.0 in,
matching the full text width of the two-column template.  The left clip card is
kept compact, every pasted frame keeps its own aspect ratio, and the gate shows
an explicit 4-4-1 MLP whose inputs are the four quantities of z.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

matplotlib.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Nimbus Roman", "Liberation Serif",
                   "DejaVu Serif"],
    "mathtext.fontset": "stix",
})

INK = "#1F2D38"
MUTED = "#55636F"
FAINT = "#8E9AA5"

RGB_EDGE, RGB_FILL = "#2E6FA8", "#EAF2FA"
POSE_EDGE, POSE_FILL = "#1F7A5A", "#E7F4EF"
GATE_EDGE, GATE_FILL = "#C07A1E", "#FDF4E3"
FUSE_EDGE, FUSE_FILL = "#4A4E7C", "#EDEEF7"
ARROW = "#6E7A85"
NODE_EDGE, NODE_FILL = "#C08A2E", "#F7E4C0"
WIRE = "#E4C089"


def box(ax, x, y, w, h, fill, edge, radius=8, lw=1.3):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle=f"round,pad=0,rounding_size={radius}",
        linewidth=lw, facecolor=fill, edgecolor=edge, zorder=1))


def arrow(ax, p1, p2, lw=1.5, style="-|>", ls="-", colour=ARROW, scale=11):
    ax.add_patch(FancyArrowPatch(
        p1, p2, arrowstyle=style, mutation_scale=scale, linewidth=lw,
        color=colour, linestyle=ls, shrinkA=2, shrinkB=2, zorder=3))


def image(ax, path: Path, x0, y0, x1, y1):
    """Paste a frame inside the box, centred, keeping its own aspect ratio."""
    data = cv2.cvtColor(cv2.imread(str(path)), cv2.COLOR_BGR2RGB)
    height, width = data.shape[:2]
    box_w, box_h = x1 - x0, y1 - y0
    scale = min(box_w / width, box_h / height)
    draw_w, draw_h = width * scale, height * scale
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    left, right = cx - draw_w / 2, cx + draw_w / 2
    bottom, top = cy - draw_h / 2, cy + draw_h / 2
    ax.imshow(data, extent=[left, right, bottom, top], aspect="auto", zorder=2)
    ax.add_patch(FancyBboxPatch(
        (left, bottom), draw_w, draw_h,
        boxstyle="round,pad=0,rounding_size=2", linewidth=0.9,
        facecolor="none", edgecolor="#B9C3CC", zorder=4))


def mlp_glyph(ax, x_in, y_top, step, labels, colours, hidden_x, out_x):
    """A correct 4-4-1 multi-layer perceptron with labelled inputs."""
    rows = [y_top - index * step for index in range(len(labels))]
    y_out = (rows[0] + rows[-1]) / 2
    radius = 3.2
    for source in rows:
        for target in rows:
            ax.plot([x_in + radius, hidden_x - radius], [source, target],
                    color=WIRE, linewidth=0.5, zorder=1)
    for source in rows:
        ax.plot([hidden_x + radius, out_x - radius], [source, y_out],
                color=WIRE, linewidth=0.5, zorder=1)
    for row in rows:
        ax.add_patch(plt.Circle((x_in, row), radius, facecolor=NODE_FILL,
                                edgecolor=NODE_EDGE, linewidth=0.8, zorder=2))
        ax.add_patch(plt.Circle((hidden_x, row), radius, facecolor=NODE_FILL,
                                edgecolor=NODE_EDGE, linewidth=0.8, zorder=2))
    ax.add_patch(plt.Circle((out_x, y_out), radius, facecolor="#F0D3A0",
                            edgecolor=NODE_EDGE, linewidth=0.9, zorder=2))
    for label, row, colour in zip(labels, rows, colours):
        ax.text(x_in - radius - 3, row, label, fontsize=6.3, color=colour,
                ha="right", va="center", zorder=3)
    ax.text(out_x + radius + 3, y_out, r"$g$", fontsize=7.2, color="#8A5A16",
            ha="left", va="center", zorder=3)
    bracket_x = x_in - radius - 22
    ax.plot([bracket_x, bracket_x], [rows[-1] - 3, rows[0] + 3],
            color="#C8A266", linewidth=0.7, zorder=1)
    ax.plot([bracket_x, bracket_x + 4], [rows[0] + 3, rows[0] + 3],
            color="#C8A266", linewidth=0.7, zorder=1)
    ax.plot([bracket_x, bracket_x + 4], [rows[-1] - 3, rows[-1] - 3],
            color="#C8A266", linewidth=0.7, zorder=1)
    ax.text(bracket_x - 2, y_out, r"$z$", fontsize=6.6, color="#8A5A16",
            ha="right", va="center")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--stem", default="71_d_3",
                    help="frame basename inside --frames")
    args = ap.parse_args()

    fig, ax = plt.subplots(figsize=(7.2, 3.0), dpi=600)
    ax.set_xlim(0, 720)
    ax.set_ylim(-30, 268)
    ax.axis("off")

    # -------------------------------------------------------- left clip card
    box(ax, 6, 30, 76, 220, "#FFFFFF", "#C4CDD5", radius=6)
    ax.text(44, 240, "Henu clip", fontsize=8.6, color=INK,
            fontweight="bold", ha="center", va="center")
    image(ax, args.frames / f"{args.stem}_scene.png", 11, 116, 77, 234)
    ax.text(44, 104, "RGB video", fontsize=7.2, color=RGB_EDGE,
            fontweight="bold", ha="center")
    ax.text(44, 91, "Dribble / Layup", fontsize=5.8, color=MUTED,
            ha="center")
    ax.text(44, 81, "Shoot", fontsize=5.8, color=MUTED, ha="center")
    ax.text(44, 66, "pose from the", fontsize=5.6, color=FAINT, ha="center")
    ax.text(44, 56, "same RGB clip", fontsize=5.6, color=FAINT, ha="center")
    ax.text(44, 42, r"$J{=}17$, $T_P{=}16$", fontsize=6.2, color=FAINT,
            ha="center")

    # --------------------------------------------------- RGB stream (row 1)
    box(ax, 88, 146, 174, 104, RGB_FILL, RGB_EDGE)
    ax.text(175, 238, "RGB appearance", fontsize=8.6, color=RGB_EDGE,
            fontweight="bold", ha="center")
    image(ax, args.frames / f"{args.stem}_rgb.png", 94, 150, 152, 238)
    ax.text(160, 205, r"$T_R=8$ frames", fontsize=7.4, color=INK)
    ax.text(160, 187, r"$64\times64\times3$", fontsize=7.4, color=INK)

    box(ax, 88, 30, 174, 104, POSE_FILL, POSE_EDGE)
    ax.text(175, 122, "RGB-derived 2D pose", fontsize=8.6, color=POSE_EDGE,
            fontweight="bold", ha="center")
    image(ax, args.frames / f"{args.stem}_pose.png", 94, 34, 152, 122)
    ax.text(160, 92, r"$J=17$ joints", fontsize=7.4, color=INK)
    ax.text(160, 74, r"$T_P=16$ frames", fontsize=7.4, color=INK)
    ax.text(160, 54, "same clip", fontsize=6.6, color=MUTED)

    arrow(ax, (82, 198), (88, 198), colour=RGB_EDGE)
    arrow(ax, (82, 84), (88, 84), colour=POSE_EDGE)

    # ------------------------------------------------------------- encoders
    box(ax, 270, 146, 124, 104, "#FFFFFF", RGB_EDGE)
    ax.text(332, 238, "RGB encoder", fontsize=8.6, color=RGB_EDGE,
            fontweight="bold", ha="center")
    for index, label in enumerate(["Conv", "Conv", "GAP"]):
        left = 277 + index * 37
        box(ax, left, 178, 34, 26, "#F6F9FC", RGB_EDGE, radius=4, lw=0.9)
        ax.text(left + 17, 191, label, fontsize=6.8, color=INK, ha="center",
                va="center")
        if index < 2:
            arrow(ax, (left + 34, 191), (left + 37, 191), lw=1.0,
                  colour=RGB_EDGE, scale=8)
    ax.text(332, 166, "4 conv + GAP", fontsize=6.6, color=MUTED, ha="center")

    box(ax, 270, 30, 124, 104, "#FFFFFF", POSE_EDGE)
    ax.text(332, 122, "Pose encoder", fontsize=8.6, color=POSE_EDGE,
            fontweight="bold", ha="center")
    for index, label in enumerate(["Conv1d", "Conv1d"]):
        left = 288 + index * 50
        box(ax, left, 62, 44, 26, "#F4FBF8", POSE_EDGE, radius=4, lw=0.9)
        ax.text(left + 22, 75, label, fontsize=6.8, color=INK, ha="center",
                va="center")
        if index == 0:
            arrow(ax, (left + 44, 75), (left + 50, 75), lw=1.0,
                  colour=POSE_EDGE, scale=8)
    ax.text(332, 50, "2 × Conv1d", fontsize=6.6, color=MUTED, ha="center")

    arrow(ax, (262, 198), (270, 198), colour=RGB_EDGE)
    arrow(ax, (262, 84), (270, 84), colour=POSE_EDGE)

    # ----------------------------------------------------------- embeddings
    box(ax, 402, 176, 68, 44, "#FFFFFF", RGB_EDGE, radius=6)
    ax.text(436, 204, r"$h_R$", fontsize=12, color=INK, ha="center")
    ax.text(436, 187, "256-d", fontsize=6.8, color=MUTED, ha="center")

    box(ax, 402, 62, 68, 44, "#FFFFFF", POSE_EDGE, radius=6)
    ax.text(436, 90, r"$h_P$", fontsize=12, color=INK, ha="center")
    ax.text(436, 73, "256-d", fontsize=6.8, color=MUTED, ha="center")

    arrow(ax, (394, 198), (402, 198), colour=RGB_EDGE)
    arrow(ax, (394, 84), (402, 84), colour=POSE_EDGE)

    # ------------------------------------------------------ gate and fusion
    box(ax, 478, 108, 132, 142, GATE_FILL, GATE_EDGE, lw=1.7)
    ax.text(544, 239, "Quality-aware gate", fontsize=8.6, color="#9A6218",
            fontweight="bold", ha="center")
    mlp_glyph(ax, x_in=530, y_top=196, step=13,
              labels=[r"$h_R$", r"$h_P$", r"$q$", r"$a$"],
              colours=["#2E6FA8", "#1F7A5A", "#B4761C", "#7A8794"],
              hidden_x=562, out_x=596)
    ax.text(544, 134, r"$g=\sigma(\mathrm{MLP}(z))$", fontsize=7.0,
            color="#8A5A16", ha="center")
    ax.text(544, 119, r"$z=[h_R;h_P;q;a]$", fontsize=6.8, color="#8A5A16",
            ha="center")

    box(ax, 478, 34, 132, 58, "#FFFDF7", GATE_EDGE, radius=6, lw=1.0)
    ax.text(544, 73, "quality $q$ + mask $a$", fontsize=7.2, color="#9A6218",
            fontweight="bold", ha="center")
    ax.text(544, 56, "valid · missing · jitter", fontsize=6.6, color=MUTED,
            ha="center")
    ax.text(544, 42, "reliability of each stream", fontsize=6.2, color=FAINT,
            ha="center")

    arrow(ax, (470, 198), (478, 198), colour=GATE_EDGE)
    arrow(ax, (470, 84), (478, 150), colour=GATE_EDGE)
    arrow(ax, (544, 92), (544, 108), colour=GATE_EDGE, ls=(0, (4, 2)))

    box(ax, 618, 108, 96, 142, FUSE_FILL, FUSE_EDGE, lw=1.5)
    ax.text(666, 239, "Fusion", fontsize=8.6, color=FUSE_EDGE,
            fontweight="bold", ha="center")
    ax.text(666, 208, r"$h=g\,h_R$", fontsize=7.6, color=FUSE_EDGE,
            ha="center")
    ax.text(666, 194, r"$+(1-g)\,h_P$", fontsize=7.6, color=FUSE_EDGE,
            ha="center")
    for index, (name, colour) in enumerate([("Dribble", "#2E6FA8"),
                                            ("Layup", "#1F7A5A"),
                                            ("Shoot", "#C0561E")]):
        cy = 170 - index * 18
        ax.add_patch(plt.Rectangle((631, cy - 4), 8, 8, facecolor=colour,
                                   edgecolor="none", zorder=2))
        ax.text(644, cy, name, fontsize=6.7, color=INK, va="center")
    ax.text(666, 114, "3-way head", fontsize=6.4, color=MUTED, ha="center")

    arrow(ax, (610, 198), (618, 198), colour=FUSE_EDGE)

    # ------------------------------------------------------------- protocol
    box(ax, 6, -26, 708, 42, "#F7F8FA", "#C9D2DA", radius=6, lw=1.0)
    ax.text(16, 6, "TRAINING", fontsize=7.6, color=FAINT, fontweight="bold")
    for index, (bold, rest) in enumerate([("50%", " R + P"), ("25%", " R miss"),
                                          ("25%", " P miss")]):
        left = 74 + index * 78
        box(ax, left, -18, 72, 22, "#FFFFFF", "#D5DCE3", radius=4, lw=0.8)
        ax.text(left + 8, -7, bold, fontsize=7.2, color=INK, fontweight="bold",
                va="center")
        ax.text(left + 30, -7, rest, fontsize=6.8, color=MUTED, va="center")
    ax.plot([318, 318], [-22, 12], color="#D5DCE3", linewidth=1.0)
    ax.text(330, 6, "TESTING", fontsize=7.6, color=FAINT, fontweight="bold")
    for index, (label, colour) in enumerate([("clean", "#3F4A55"),
                                             ("missing R/P", "#8A5A16"),
                                             ("RGB noise", "#2E6FA8"),
                                             ("pose jitter", "#1F7A5A")]):
        left = 386 + index * 82
        box(ax, left, -18, 78, 22, "#FFFFFF", "#D5DCE3", radius=4, lw=0.8)
        ax.text(left + 39, -7, label, fontsize=6.8, color=colour, ha="center",
                va="center")

    # ------------------------------------------------------------ panel tags
    ax.text(6, 258, "(a) Representation streams", fontsize=8.8, color=FAINT,
            fontweight="bold")
    ax.text(714, 258, "(b) Reliability-aware fusion", fontsize=8.8,
            color=FAINT, fontweight="bold", ha="right")

    fig.subplots_adjust(left=0.004, right=0.996, top=0.995, bottom=0.005)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.out, facecolor="white")
    plt.close(fig)
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
