"""Repack the local (CUDA) results into the layout ``gen_paper_figures`` reads.

The paper figures were originally generated from ``incoming/`` (the packaged
run from the other machine).  This script mirrors the freshly re-trained local
run into the same structure so the same figure code can be reused unchanged:

    incoming_local/stage2/robust_<mode>_seed<seed>/confusion_clean.tsv
    incoming_local/stage3/reports/main_summary.csv      (long: mode,metric,mean,std)
    incoming_local/stage3/reports/robust_summary.csv    (already the right shape)
    incoming_local/logs/logs/final_<mode>_seed<seed>.log
"""

from __future__ import annotations

import argparse
import csv
import shutil
from pathlib import Path

METRIC_ROWS = [("accuracy", "Accuracy"), ("macro_f1", "Macro-F1"),
               ("f1_dribble", "Dribble F1"), ("f1_layup", "Layup F1"),
               ("f1_shoot", "Shoot F1")]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()

    root, out = args.root, args.out
    outputs, reports = root / "outputs", root / "reports"
    for sub in ("stage2", "stage3/reports", "logs/logs"):
        (out / sub).mkdir(parents=True, exist_ok=True)

    # long-format main summary
    with (reports / "main_summary.csv").open(encoding="utf-8-sig") as handle:
        main = {row["mode"]: row for row in csv.DictReader(handle)}
    long_rows = []
    for mode, row in sorted(main.items()):
        for key, label in METRIC_ROWS:
            long_rows.append({"mode": mode, "metric": label,
                              "n_seeds": row["n"],
                              "mean": row[f"{key}_mean"],
                              "std": row[f"{key}_std"]})
    with (out / "stage3/reports/main_summary.csv").open(
            "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["mode", "metric", "n_seeds",
                                                    "mean", "std"])
        writer.writeheader()
        writer.writerows(long_rows)
    print(f"main_summary.csv: {len(long_rows)} rows, "
          f"modes={sorted(main)}")

    shutil.copyfile(reports / "robust_summary.csv",
                    out / "stage3/reports/robust_summary.csv")
    print("robust_summary.csv copied")

    staged = 0
    for folder in sorted(outputs.glob("robust_*_seed*")):
        target = out / "stage2" / folder.name
        target.mkdir(parents=True, exist_ok=True)
        for name in ("confusion_clean.tsv", "metrics.tsv", "config.json"):
            source = folder / name
            if source.exists():
                shutil.copyfile(source, target / name)
        staged += 1
    print(f"stage2: {staged} robustness folders")

    logs = 0
    for folder in sorted(outputs.glob("final_*_seed*")):
        source = folder / "console.log"
        if source.exists():
            shutil.copyfile(source, out / "logs/logs" / f"{folder.name}.log")
            logs += 1
    print(f"logs: {logs} training logs")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
