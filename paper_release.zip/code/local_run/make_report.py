"""Render the paper-ready result tables into reports/RESULTS.md."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

ORDER = ["rgb", "pose", "sum", "concat", "ours", "fixed"]


def read(path: Path) -> list[dict]:
    with path.open(encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def pm(value: str, std: str) -> str:
    try:
        return f"{float(value):.4f} ± {float(std):.4f}"
    except (TypeError, ValueError):
        return "-"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    args = ap.parse_args()
    reports = args.root / "reports"
    lines: list[str] = []

    main_rows = {r["mode"]: r for r in read(reports / "main_summary.csv")}
    lines.append("# Henu-MultiSubjects RGB / RGB-derived pose 实验结果\n")
    lines.append("数据集固定为 4096 个视频，subject 不交叉：train 2852 / 691 subjects，"
                 "val 625 / 149 subjects，test 619 / 148 subjects。"
                 "Pose 是 RGB 视频导出的 17-joint 2D 表示。\n")
    lines.append("## 主结果（三个随机种子 2026/2027/2028 的均值 ± 标准差）\n")
    lines.append("| 模型 | Accuracy | Macro-F1 | Dribble F1 | Layup F1 | Shoot F1 | seeds |")
    lines.append("| --- | --- | --- | --- | --- | --- | --- |")
    for mode in ORDER:
        r = main_rows.get(mode)
        if not r:
            continue
        lines.append(
            f"| {mode} | {pm(r['accuracy_mean'], r['accuracy_std'])} "
            f"| {pm(r['macro_f1_mean'], r['macro_f1_std'])} "
            f"| {pm(r['f1_dribble_mean'], r['f1_dribble_std'])} "
            f"| {pm(r['f1_layup_mean'], r['f1_layup_std'])} "
            f"| {pm(r['f1_shoot_mean'], r['f1_shoot_std'])} | {r['n']} |")

    robust_path = reports / "robust_summary.csv"
    if robust_path.exists():
        rows = read(robust_path)
        grouped: dict[str, list[dict]] = {}
        for r in rows:
            grouped.setdefault(r["mode"], []).append(r)
        groups = {
            "RGB 缺失": [("missing_rgb_0.2", "20%"), ("missing_rgb_0.4", "40%"),
                       ("missing_rgb_0.6", "60%"), ("missing_rgb_1", "100%")],
            "Pose 缺失": [("missing_pose_0.2", "20%"), ("missing_pose_0.4", "40%"),
                        ("missing_pose_0.6", "60%"), ("missing_pose_1", "100%")],
            "RGB 高斯噪声": [("rgb_gaussian_0.02", "0.02"), ("rgb_gaussian_0.05", "0.05"),
                          ("rgb_gaussian_0.1", "0.1")],
            "Pose 抖动": [("pose_jitter_0.01", "0.01"), ("pose_jitter_0.03", "0.03"),
                        ("pose_jitter_0.05", "0.05")],
        }
        lines.append("\n## 鲁棒性（三个种子的均值 ± 标准差，括号内为相对 clean 的下降）\n")
        for title, conditions in groups.items():
            lines.append(f"\n### {title}\n")
            header = "| 模型 | clean | " + " | ".join(label for _, label in conditions) + " |"
            lines.append(header)
            lines.append("| --- |" + " --- |" * (len(conditions) + 1))
            for mode in ["sum", "ours", "fixed", "concat"]:
                if mode not in grouped:
                    continue
                by_condition = {r["condition"]: r for r in grouped[mode]}
                cells = []
                for condition in ["clean"] + [c for c, _ in conditions]:
                    r = by_condition.get(condition)
                    if not r:
                        cells.append("-")
                        continue
                    value = pm(r["macro_f1_mean"], r["macro_f1_std"])
                    if condition != "clean":
                        value += f" ({float(r['delta_macro_f1_mean']):+.4f})"
                    cells.append(value)
                lines.append(f"| {mode} | " + " | ".join(cells) + " |")

    figures = reports / "figures"
    if figures.exists():
        lines.append("\n## 图\n")
        for name in sorted(p.name for p in figures.glob("*.png")):
            lines.append(f"- reports/figures/{name}")

    (reports / "RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {reports / 'RESULTS.md'}")


if __name__ == "__main__":
    main()
