"""Export the RGB / pose / scene crops that Figure 1 needs.

The frame is chosen so that the whole player is visible, the pose is well
tracked and moving, and the burned-in surveillance clock (present in part of the
dataset) never overlaps the person, so the crop stays clean without cutting the
head off.
"""

from __future__ import annotations

import argparse
import csv
import pickle
from pathlib import Path

import cv2
import numpy as np

BONES = [(0, 1), (0, 2), (1, 3), (2, 4), (0, 5), (0, 6), (5, 6), (5, 7),
         (7, 9), (6, 8), (8, 10), (5, 11), (6, 12), (11, 13), (12, 14),
         (13, 15), (14, 16), (11, 12)]
HEAD = [0, 1, 2, 3, 4]
FEET = [15, 16]


def load_pose(pose_root: Path) -> dict[str, dict]:
    records: dict[str, dict] = {}
    for name in ("train.pkl", "val.pkl"):
        with (pose_root / name).open("rb") as handle:
            for item in pickle.load(handle):
                records[str(item["frame_dir"])] = item
    return records


def content_box(frame, threshold: int = 18):
    grey = frame.mean(axis=2)
    columns = np.where(grey.mean(axis=0) > threshold)[0]
    rows = np.where(grey.mean(axis=1) > threshold)[0]
    if not len(columns) or not len(rows):
        return 0, 0, frame.shape[1], frame.shape[0]
    return int(columns[0]), int(rows[0]), int(columns[-1] + 1), int(rows[-1] + 1)


def clock_band(frame, x0, y0, x1, y1, white=195, frac=0.10, max_share=0.20):
    """Rows of the upper content occupied by the wide white clock text.

    The clock is neutral white, so pixels count only when every channel is
    bright; that keeps the warm wooden floor from being mistaken for text.
    """
    patch = frame[y0:y0 + int(0.45 * (y1 - y0)), x0:x1]
    if patch.size == 0:
        return None
    white_px = (patch.min(axis=2) >= white).mean(axis=1)
    hits = np.where(white_px > frac)[0]
    if not len(hits):
        return None
    rows = y0 + hits
    groups = np.split(rows, np.where(np.diff(rows) > 4)[0] + 1)
    groups = [g for g in groups if len(g) >= 5]
    if not groups:
        return None
    best = max(groups, key=len)
    if len(best) > max_share * (y1 - y0):
        return None
    return int(best.min()), int(best.max())


def fit_aspect(x0, y0, x1, y1, aspect, width, height):
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    w, h = x1 - x0, y1 - y0
    if w / h < aspect:
        w = h * aspect
    else:
        h = w / aspect
    x0, x1 = cx - w / 2, cx + w / 2
    y0, y1 = cy - h / 2, cy + h / 2
    if x0 < 0:
        x1 -= x0
        x0 = 0
    if x1 > width:
        x0 -= (x1 - width)
        x1 = width
    if y0 < 0:
        y1 -= y0
        y0 = 0
    if y1 > height:
        y0 -= (y1 - height)
        y1 = height
    return int(max(0, x0)), int(max(0, y0)), int(x1), int(y1)


def trim_black(image, threshold: int = 18):
    grey = image.mean(axis=2)
    columns = np.where(grey.mean(axis=0) > threshold)[0]
    rows = np.where(grey.mean(axis=1) > threshold)[0]
    if not len(columns) or not len(rows):
        return image, np.array([0, 0])
    return (image[rows[0]:rows[-1] + 1, columns[0]:columns[-1] + 1],
            np.array([columns[0], rows[0]]))


def draw_pose(image, points, valid):
    overlay = image.copy()
    for a, b in BONES:
        if valid[a] and valid[b]:
            cv2.line(overlay, tuple(np.round(points[a]).astype(int)),
                     tuple(np.round(points[b]).astype(int)),
                     (70, 235, 90), 4, cv2.LINE_AA)
    for index, point in enumerate(points):
        if not valid[index]:
            continue
        centre = tuple(np.round(point).astype(int))
        cv2.circle(overlay, centre, 6, (255, 255, 255), -1, cv2.LINE_AA)
        cv2.circle(overlay, centre, 4, (60, 120, 255), -1, cv2.LINE_AA)
    return overlay


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True, type=Path)
    ap.add_argument("--pose-root", required=True, type=Path)
    ap.add_argument("--clip", required=True)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--frame", type=int, default=-1)
    ap.add_argument("--top", type=int, default=12)
    args = ap.parse_args()

    rows = {r["frame_dir"]: r for r in csv.DictReader(
        args.manifest.open(encoding="utf-8"))}
    row = rows[args.clip]
    item = load_pose(args.pose_root)[args.clip]
    xy = item["keypoint"][0].astype(np.float32)
    score = item["keypoint_score"][0].astype(np.float32)

    capture = cv2.VideoCapture(row["path"])
    total = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    valid = score >= 0.4
    motion = np.concatenate([[0.0], np.linalg.norm(np.diff(xy, axis=0), axis=2)
                             .mean(axis=1)])

    if args.frame >= 0:
        order = [args.frame]
    else:
        order = []
        for index in range(min(len(xy), total)):
            take = np.where(valid[index])[0]
            if len(take) < 12:
                continue
            if not all(valid[index, j] for j in HEAD + FEET):
                continue
            order.append(index)
        order.sort(key=lambda i: -(score[i].mean() * 2.0 + motion[i] / 40.0))
        order = order[:args.top]

    chosen = None
    for index in order:
        capture.set(cv2.CAP_PROP_POS_FRAMES, int(index))
        ok, frame = capture.read()
        if not ok:
            continue
        x0, y0, x1, y1 = content_box(frame)
        band = clock_band(frame, x0, y0, x1, y1)
        take = np.where(valid[index])[0]
        head = float(xy[index, HEAD, 1].min())
        feet = float(xy[index, FEET, 1].max())
        if band is not None and band[0] - 8 < feet and band[1] + 8 > head:
            print(f"frame {index}: clock {band} overlaps the player "
                  f"({head:.0f}..{feet:.0f}) — rejected")
            continue
        chosen = (index, frame, (x0, y0, x1, y1), band, head, feet)
        break

    capture.release()
    if chosen is None:
        raise SystemExit(f"no clean frame found for {args.clip}")

    index, frame, (cx0, cy0, cx1, cy1), band, head, feet = chosen
    # drop a clock band that sits above the player, then keep the scene as is
    if band is not None:
        cy0 = band[1] + 4

    # the source clips are tall strips; take a slightly wider window around the
    # player so the scene thumbnail is not a sliver
    take = valid[index]
    person_x = (xy[index, take, 0].min() + xy[index, take, 0].max()) / 2
    person_y = (xy[index, take, 1].min() + xy[index, take, 1].max()) / 2
    strip_w, strip_h = cx1 - cx0, cy1 - cy0
    win_h = min(strip_h, strip_w / 0.55)
    win_w = win_h * 0.55
    sx0 = int(min(max(person_x - win_w / 2, cx0), cx1 - win_w))
    sy0 = int(min(max(person_y - win_h / 2, cy0), cy1 - win_h))
    sx1, sy1 = int(sx0 + win_w), int(sy0 + win_h)
    scene = frame[sy0:sy1, sx0:sx1].copy()

    points = xy[index] - np.array([sx0, sy0], dtype=np.float32)
    height, width = scene.shape[:2]
    take = valid[index]
    xs, ys = points[take, 0], points[take, 1]
    rx0, ry0, rx1, ry1 = fit_aspect(xs.min(), ys.min(), xs.max(), ys.max(),
                                    4 / 5, width, height)
    pad_x = int(0.16 * (rx1 - rx0))
    pad_y = int(0.08 * (ry1 - ry0))
    box = (max(0, rx0 - pad_x), max(0, ry0 - pad_y),
           min(width, rx1 + pad_x), min(height, ry1 + pad_y))
    crop = scene[box[1]:box[3], box[0]:box[2]].copy()
    crop, shift = trim_black(crop)
    origin = np.array([box[0], box[1]]) + shift
    overlay = draw_pose(crop, points - origin, take)

    # remove any clock remnant from the tight crops as a final guard
    args.out.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(args.out / f"{args.clip}_scene.png"), scene)
    cv2.imwrite(str(args.out / f"{args.clip}_rgb.png"), crop)
    cv2.imwrite(str(args.out / f"{args.clip}_pose.png"), overlay)
    print(f"{args.clip}: frame={index} conf={score[index].mean():.3f} "
          f"motion={motion[index]:.2f} clock={band} "
          f"crop={crop.shape[1]}x{crop.shape[0]} scene={scene.shape[1]}x{scene.shape[0]}")


if __name__ == "__main__":
    main()
