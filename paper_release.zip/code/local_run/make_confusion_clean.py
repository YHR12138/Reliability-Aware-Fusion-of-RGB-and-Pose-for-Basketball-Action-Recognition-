"""Write the clean-test confusion matrix in the packaged ``confusion_clean.tsv``
layout (header row plus three count rows) for a trained checkpoint."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

CLASSES = ["Dribble", "Layup", "Shoot"]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    ap.add_argument("--cache-dir", required=True, type=Path)
    ap.add_argument("--mode", required=True)
    ap.add_argument("--checkpoint", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--fixed-alpha", type=float, default=0.5)
    args = ap.parse_args()

    root = args.root.resolve()
    import sys
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(root / "local_run"))
    import cached_data
    cached_data.install(args.cache_dir)
    from run_multimodal_baseline import FusionModel

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dataset = cached_data.CachedMultiDataset(
        root / "local_run" / "manifest_local.csv", root / "pose_data", "test",
        8, 16, 64, False, 0, args.mode != "pose", args.cache_dir)
    loader = DataLoader(dataset, batch_size=8, shuffle=False, num_workers=0)

    model = FusionModel(args.mode, fixed_alpha=args.fixed_alpha).to(device)
    state = torch.load(args.checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(state["model"] if "model" in state else state)
    model.eval()

    cm = np.zeros((3, 3), dtype=np.int64)
    with torch.inference_mode():
        for rgb, pose, quality, y, _ in loader:
            logits = model(rgb.to(device), pose.to(device), quality.to(device))
            pred = logits.argmax(1).cpu().numpy()
            for truth, guess in zip(y.numpy(), pred):
                cm[truth, guess] += 1

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["true\\pred"] + CLASSES + ["total"])
        for index, name in enumerate(CLASSES):
            writer.writerow([name] + cm[index].tolist() + [int(cm[index].sum())])
    print(f"{args.out}: {cm.tolist()}")


if __name__ == "__main__":
    main()
