"""Remap the fixed three-person manifest onto this machine's copy of the data.

The canonical manifest (``manifest_pose_subject_disjoint.csv``) was produced on
another machine and its ``path`` column points at
``D:\\Henu-MultiSubjects\\data\\Subjects1000\\subjects1000``.  This machine keeps
the same 4096 videos but in a flat per-split layout:

    D:\\BaiduNetdiskDownload\\MultiSubjects_train_val_test\\MultiSubjects_train_val_test\\{split}\\*.mp4

Nothing about the split, the labels or the pose assignment is changed here; only
the ``path`` column is resolved to a video that actually exists locally.  The
original manifest is never modified.
"""

from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path


def build_index(video_root: Path) -> dict[str, list[Path]]:
    index: dict[str, list[Path]] = {}
    for path in video_root.rglob("*.mp4"):
        index.setdefault(path.name.lower(), []).append(path)
    return index


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True, type=Path)
    ap.add_argument("--video-root", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()

    index = build_index(args.video_root)
    with args.manifest.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fields = list(reader.fieldnames or [])
        rows = list(reader)

    missing: list[str] = []
    remapped = 0
    for row in rows:
        candidates = index.get(row["video"].lower())
        if not candidates:
            missing.append(row["video"])
            continue
        # Prefer the copy that sits in the folder named after the manifest split
        # so the on-disk layout stays readable; fall back to the first copy.
        chosen = next(
            (p for p in candidates if p.parent.name == row["split"]),
            sorted(candidates)[0],
        )
        if Path(row["path"]) != chosen:
            remapped += 1
        row["path"] = str(chosen)

    if missing:
        raise SystemExit(f"{len(missing)} videos not found locally, e.g. {missing[:5]}")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    print(f"rows={len(rows)} path_remapped={remapped} missing=0")
    for split in ("train", "val", "test"):
        subset = [r for r in rows if r["split"] == split]
        print(
            f"{split}: videos={len(subset)} "
            f"subjects={len({r['subject'] for r in subset})} "
            f"classes={dict(Counter(r['label_name'] for r in subset))}"
        )
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
