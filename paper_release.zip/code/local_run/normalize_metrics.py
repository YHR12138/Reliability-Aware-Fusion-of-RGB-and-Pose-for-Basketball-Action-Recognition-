"""Normalise the ``np.float64(...)`` repr that NumPy 2.x writes into metrics.txt.

The reference machine ran an older NumPy whose ``repr`` of a float64 was a plain
number, so its metrics.txt files read

    test=(0.557, 0.794, 0.736, [0.861, 0.502, 0.846])

with NumPy 2.x the same line becomes ``[np.float64(0.861), ...]``.  The official
summariser (``summarize_results.py``) parses the plain form.  This script rewrites
the formatting only; every value is byte-for-byte the same number.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

PATTERN = re.compile(r"np\.float64\(([^()]+)\)")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    args = ap.parse_args()
    changed = []
    for path in sorted((args.root / "outputs").glob("final_*_seed*/metrics.txt")):
        text = path.read_text(encoding="utf-8")
        fixed = PATTERN.sub(r"\1", text)
        if fixed != text:
            path.write_text(fixed, encoding="utf-8")
            changed.append(path.parent.name)
    print(f"normalised {len(changed)} files")
    for name in changed:
        print("  " + name)


if __name__ == "__main__":
    main()
