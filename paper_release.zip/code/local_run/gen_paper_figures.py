"""Generate the publication figures for the ICCIP paper from the official run.

All numbers come from the packaged results: the main-model metrics.json files,
the robustness metrics.tsv/confusion_clean.tsv files, and the training logs.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

matplotlib.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Nimbus Roman", "Liberation Serif",
                   "DejaVu Serif"],
    "mathtext.fontset": "stix",
})

MODES = ["rgb", "pose", "sum", "concat", "ours", "fixed"]
LABELS = {"rgb": "RGB", "pose": "Pose", "sum": "Sum",
          "concat": "Concat", "ours": "Ours", "fixed": "Fixed"}
DESC = {"rgb": "RGB-only", "pose": "Pose-only", "sum": "Sum",
        "concat": "Concat", "ours": "Ours (gate)", "fixed": "Fixed (no conf.)"}
COLORS = {"sum": "#4C72B0", "fixed": "#55A868", "ours": "#C44E52",
          "concat": "#8172B2", "rgb": "#937860", "pose": "#DA8BC3"}
# All robustness curves are solid; the three rules are separated by colour and
# by marker shape, which also survives greyscale printing.  A dashed "fixed"
# curve was only needed while it was numerically identical to "sum".
STYLES = {"sum": "-", "fixed": "-", "ours": "-"}
MARKERS = {"sum": "o", "fixed": "^", "ours": "s"}
ZORDER = {"sum": 3, "fixed": 4, "ours": 5}
ROBUST_MODES = ["sum", "ours", "fixed"]


def read_summary(path: Path) -> dict[str, dict[str, tuple[float, float]]]:
    out: dict[str, dict[str, tuple[float, float]]] = {}
    with path.open(encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            out.setdefault(row["mode"], {})[row["metric"]] = (
                float(row["mean"]), float(row["std"]))
    return out


def panel_main(main, path: Path) -> None:
    modes = [m for m in MODES if m in main]
    acc = [main[m]["Accuracy"] for m in modes]
    f1 = [main[m]["Macro-F1"] for m in modes]
    x = np.arange(len(modes))
    w = 0.38
    fig, ax = plt.subplots(figsize=(3.4, 2.3), dpi=600)
    ax.bar(x - w / 2, [v[0] for v in acc], w, yerr=[v[1] for v in acc],
           capsize=3, label="Accuracy", color="#4C72B0", edgecolor="black",
           linewidth=0.4)
    ax.bar(x + w / 2, [v[0] for v in f1], w, yerr=[v[1] for v in f1],
           capsize=3, label="Macro-F1", color="#DD8452", edgecolor="black",
           linewidth=0.4)
    for i, (a, b) in enumerate(zip(acc, f1)):
        ax.text(i - w / 2, a[0] + 0.022, f"{a[0]:.3f}", ha="center", fontsize=5.2)
        ax.text(i + w / 2, b[0] + 0.022, f"{b[0]:.3f}", ha="center", fontsize=5.2)
    ax.set_xticks(x, [LABELS[m] for m in modes], fontsize=6.2)
    ax.set_ylim(0, 1.0)
    ax.set_ylabel("score", fontsize=7)
    ax.tick_params(labelsize=6.2)
    ax.grid(axis="y", alpha=0.3, linewidth=0.5)
    ax.legend(fontsize=6.2, frameon=False, ncol=2)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def read_robust(path: Path) -> list[dict]:
    with path.open(encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def panel_curves(rows, conditions, xlabel, title, path, logx=False):
    metrics = [("accuracy", "Accuracy"), ("macro_f1", "Macro-F1")]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.7), dpi=300)
    for ax, (key, label) in zip(axes, metrics):
        for mode in ROBUST_MODES:
            xs, ys, es = [], [], []
            for condition, level in conditions:
                match = [r for r in rows
                         if r["mode"] == mode and r["condition"] == condition]
                if not match:
                    continue
                xs.append(level)
                ys.append(float(match[0][f"{key}_mean"]))
                es.append(float(match[0][f"{key}_std"]))
            if xs:
                ax.errorbar(xs, ys, yerr=es, marker=MARKERS[mode],
                            markersize=3.5,
                            capsize=2.5, linewidth=1.2, color=COLORS[mode],
                            linestyle=STYLES[mode], zorder=ZORDER[mode],
                            label=DESC[mode])
        ax.set_xlabel(xlabel, fontsize=8)
        ax.set_ylabel(label, fontsize=8)
        ax.tick_params(labelsize=7)
        ax.grid(alpha=0.3, linewidth=0.5)
        if logx:
            pass
    axes[1].legend(fontsize=7, frameon=False)
    fig.suptitle(title, fontsize=9, y=1.02)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def panel_confusion(stage2: Path, path: Path) -> None:
    fig, axes = plt.subplots(2, 1, figsize=(3.4, 3.5), dpi=600)
    classes = ["Dribble", "Layup", "Shoot"]
    for ax, mode in zip(axes, ["ours", "sum"]):
        with (stage2 / f"robust_{mode}_seed2026" / "confusion_clean.tsv").open(
                encoding="utf-8") as f:
            rows = list(csv.reader(f, delimiter="\t"))
        cm = np.array([[float(v) for v in row[1:4]] for row in rows[1:4]])
        norm = cm / cm.sum(axis=1, keepdims=True)
        ax.imshow(norm, cmap="Blues", vmin=0, vmax=1)
        for i in range(3):
            for j in range(3):
                ax.text(j, i, f"{int(cm[i, j])}\n{norm[i, j]:.2f}", ha="center",
                        va="center", fontsize=5.6,
                        color="black" if norm[i, j] < 0.6 else "white")
        ax.set_xticks(range(3), classes, fontsize=6.2)
        ax.set_yticks(range(3), classes, fontsize=6.2)
        ax.set_xlabel("predicted", fontsize=6.6)
        ax.set_title(DESC[mode] + " (clean test, seed 2026)", fontsize=6.6)
    axes[1].set_ylabel("true", fontsize=6.6)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def panel_grid(rows, groups, path, xlabel):
    """2x2 grid: missing-RGB/missing-pose or RGB-noise/pose-jitter."""
    metrics = [("accuracy", "Accuracy"), ("macro_f1", "Macro-F1")]
    fig, axes = plt.subplots(2, 2, figsize=(3.4, 3.9), dpi=600)
    for row, (title, conditions) in enumerate(groups):
        for col, (key, label) in enumerate(metrics):
            ax = axes[row][col]
            for mode in ROBUST_MODES:
                xs, ys, es = [], [], []
                for condition, level in conditions:
                    match = [r for r in rows
                             if r["mode"] == mode and r["condition"] == condition]
                    if not match:
                        continue
                    xs.append(level)
                    ys.append(float(match[0][f"{key}_mean"]))
                    es.append(float(match[0][f"{key}_std"]))
                if xs:
                    ax.errorbar(xs, ys, yerr=es, marker=MARKERS[mode],
                                markersize=3.2,
                                capsize=2.2, linewidth=1.1, color=COLORS[mode],
                                linestyle=STYLES[mode], zorder=ZORDER[mode],
                                label=DESC[mode])
            ax.set_xlabel(xlabel if row == 1 else "", fontsize=6.4)
            ax.set_ylabel(label, fontsize=6.6)
            ax.tick_params(labelsize=5.8)
            ax.grid(alpha=0.3, linewidth=0.5)
            if col == 0:
                ax.set_title(title, fontsize=6.8)
            if row == 0 and col == 1:
                ax.legend(fontsize=5.8, frameon=False)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


# Two log flavours: the packaged run prints "[epoch i/10] train loss=... acc=...
# macroF1=... | val loss=... acc=... macroF1=...", the local run prints
# "epoch=i train=(loss, acc, macroF1, [...]) val=(loss, acc, macroF1, [...])".
EPOCH_RE = re.compile(
    r"\[epoch (\d+)/(\d+)\] train loss=([\d.]+) acc=([\d.]+) macroF1=([\d.]+) "
    r"\| val loss=([\d.]+) acc=([\d.]+) macroF1=([\d.]+)")
EPOCH_LOCAL_RE = re.compile(
    r"epoch=(\d+) train=\(([-\d.eE+]+), ([\d.]+), ([\d.eE+-]+), \[.*?\]\) "
    r"val=\(([-\d.eE+]+), ([\d.]+), ([\d.eE+-]+),")


def panel_training(logs: Path, path: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(3.4, 2.2), dpi=600)
    for mode in ["ours", "sum", "rgb", "pose"]:
        for seed in (2026, 2027, 2028):
            log = logs / f"final_{mode}_seed{seed}.log"
            if not log.exists():
                continue
            text = log.read_text(encoding="utf-8", errors="ignore")
            epochs = EPOCH_RE.findall(text)
            if not epochs:
                epochs = EPOCH_LOCAL_RE.findall(text)
            if not epochs:
                continue
            xs = [int(e[0]) for e in epochs]
            if len(epochs[0]) == 8:
                tr = [float(e[4]) for e in epochs]
                va = [float(e[7]) for e in epochs]
            else:
                tr = [float(e[3]) for e in epochs]
                va = [float(e[6]) for e in epochs]
            axes[0].plot(xs, tr, color=COLORS[mode], alpha=0.55, linewidth=1)
            axes[1].plot(xs, va, color=COLORS[mode], alpha=0.55, linewidth=1)
    for ax, title in zip(axes, ["Training Macro-F1", "Validation Macro-F1"]):
        ax.set_xlabel("epoch", fontsize=8)
        ax.set_ylabel("Macro-F1", fontsize=8)
        ax.tick_params(labelsize=7)
        ax.grid(alpha=0.3, linewidth=0.5)
        ax.set_title(title, fontsize=8)
    handles = [plt.Line2D([], [], color=COLORS[m], label=DESC[m])
               for m in ["ours", "sum", "rgb", "pose"]]
    axes[1].legend(handles=handles, fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def panel_pipeline(path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7.2, 2.5), dpi=300)
    ax.set_xlim(0, 10.1)
    ax.set_ylim(-0.15, 3.15)
    ax.axis("off")

    def box(x, y, w, h, text, fc="#EAF1F8", ec="#2F4B6E", fs=7.0):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.06",
                                    linewidth=0.8, facecolor=fc, edgecolor=ec))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
                fontsize=fs, linespacing=1.35)

    def arrow(x1, y1, x2, y2, style="-|>", ls="-"):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style,
                                     mutation_scale=8, linewidth=0.8,
                                     color="#333333", linestyle=ls))

    box(0.05, 1.95, 1.45, 0.95, "RGB clip\n$T_r$=8 frames\n64x64")
    box(0.05, 0.45, 1.45, 0.95, "17-joint pose\n$T_p$=16 frames\n(RGB-derived)")
    box(1.90, 1.95, 1.70, 0.95, "RGB encoder\n4 conv + GAP\n(BN, ReLU)")
    box(1.90, 0.45, 1.70, 0.95, "Pose encoder\n2 x Conv1d\n(34-128-192)")
    box(4.00, 1.95, 1.05, 0.95, "$h_r$\n(256)")
    box(4.00, 0.45, 1.05, 0.95, "$h_p$\n(256)")
    box(3.80, -0.12, 1.55, 0.34, "quality $q$ + flags $a$", fc="#F5EFE0", fs=6.4)
    box(5.60, 0.85, 1.80, 1.55,
        "gate MLP\n$[h_r;h_p;q;a]$\n128 -> 1\n$g=\\sigma(\\cdot)$", fs=6.6)
    box(7.75, 0.85, 1.45, 1.55, "fusion\n$g\\,h_r$\n$+(1-g)\\,h_p$", fs=6.8)
    box(9.50, 0.85, 0.55, 1.55, "linear\nclf.\n3 cls.", fs=6.2)

    arrow(1.50, 2.42, 1.90, 2.42)
    arrow(1.50, 0.92, 1.90, 0.92)
    arrow(3.60, 2.42, 4.00, 2.42)
    arrow(3.60, 0.92, 4.00, 0.92)
    arrow(5.05, 2.42, 5.60, 1.95)
    arrow(5.05, 0.92, 5.60, 1.25)
    arrow(5.35, 0.20, 5.62, 0.90)
    arrow(7.40, 1.62, 7.75, 1.62)
    arrow(9.20, 1.62, 9.50, 1.62)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--incoming", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    reports = args.incoming / "stage3" / "reports"
    stage2 = args.incoming / "stage2"
    logs = args.incoming / "logs" / "logs"

    main_sum = read_summary(reports / "main_summary.csv")
    panel_main(main_sum, out / "fig1_main_models.png")

    robust = read_robust(reports / "robust_summary.csv")
    panel_curves(robust,
                 [("clean", 0.0), ("missing_rgb_0.2", 0.2), ("missing_rgb_0.4", 0.4),
                  ("missing_rgb_0.6", 0.6), ("missing_rgb_1", 1.0)],
                 "missing rate", "Missing RGB", out / "fig2_missing_rgb.png")
    panel_curves(robust,
                 [("clean", 0.0), ("missing_pose_0.2", 0.2), ("missing_pose_0.4", 0.4),
                  ("missing_pose_0.6", 0.6), ("missing_pose_1", 1.0)],
                 "missing rate", "Missing pose", out / "fig3_missing_pose.png")
    panel_curves(robust,
                 [("clean", 0.0), ("rgb_gaussian_0.02", 0.02),
                  ("rgb_gaussian_0.05", 0.05), ("rgb_gaussian_0.1", 0.1)],
                 "Gaussian sigma", "RGB Gaussian noise", out / "fig4_noise_rgb.png")
    panel_curves(robust,
                 [("clean", 0.0), ("pose_jitter_0.01", 0.01),
                  ("pose_jitter_0.03", 0.03), ("pose_jitter_0.05", 0.05)],
                 "jitter level", "Pose coordinate jitter", out / "fig5_noise_pose.png")
    panel_confusion(stage2, out / "fig6_confusion.png")
    panel_pipeline(out / "fig7_pipeline.png")
    if logs.exists():
        panel_training(logs, out / "fig8_training_curves.png")

    missing_groups = [
        ("Missing RGB", [("clean", 0.0), ("missing_rgb_0.2", 0.2),
                         ("missing_rgb_0.4", 0.4), ("missing_rgb_0.6", 0.6),
                         ("missing_rgb_1", 1.0)]),
        ("Missing pose", [("clean", 0.0), ("missing_pose_0.2", 0.2),
                          ("missing_pose_0.4", 0.4), ("missing_pose_0.6", 0.6),
                          ("missing_pose_1", 1.0)]),
    ]
    noise_groups = [
        ("RGB Gaussian noise", [("clean", 0.0), ("rgb_gaussian_0.02", 0.02),
                                ("rgb_gaussian_0.05", 0.05),
                                ("rgb_gaussian_0.1", 0.1)]),
        ("Pose coordinate jitter", [("clean", 0.0), ("pose_jitter_0.01", 0.01),
                                    ("pose_jitter_0.03", 0.03),
                                    ("pose_jitter_0.05", 0.05)]),
    ]
    panel_grid(robust, missing_groups, out / "fig9_missing_all.png", "missing rate")
    panel_grid(robust, noise_groups, out / "fig10_noise_all.png", "corruption level")
    print(f"figures written to {out}")
    for p in sorted(out.glob("*.png")):
        print("  " + p.name)


if __name__ == "__main__":
    main()
