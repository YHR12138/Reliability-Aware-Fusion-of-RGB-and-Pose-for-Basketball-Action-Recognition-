"""Acceptance checks for the finished run (manual section 9).

For every mode/seed it verifies the split sizes, that the checkpoint is
readable, that ``metrics.txt`` records the validation Macro-F1, and - when a
robustness directory exists - that its ``clean`` row reproduces the test metrics
stored in ``metrics.txt`` exactly.  That last check is what catches parsing
mistakes between the two files.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import torch

MODES = ["rgb", "pose", "sum", "concat", "ours", "fixed"]
SEEDS = [2026, 2027, 2028, 2029, 2030]
EXPECTED_SPLIT = "train=2852 val=625 test=619"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    args = ap.parse_args()
    outputs = args.root / "outputs"
    failures: list[str] = []
    checked = 0

    for mode in MODES:
        for seed in SEEDS:
            name = f"final_{mode}_seed{seed}"
            out = outputs / name
            best, metrics = out / "best.pt", out / "metrics.txt"
            if not best.exists() or not metrics.exists():
                failures.append(f"{name}: missing best.pt/metrics.txt")
                continue
            text = metrics.read_text(encoding="utf-8")
            if EXPECTED_SPLIT not in text:
                failures.append(f"{name}: split mismatch")
            if f"mode={mode}" not in text:
                failures.append(f"{name}: mode mismatch")
            state = torch.load(best, map_location="cpu", weights_only=False)
            if not isinstance(state.get("val_macro_f1"), float):
                failures.append(f"{name}: checkpoint has no val_macro_f1")
            line = [l for l in text.splitlines() if l.startswith("test=")][0]
            values = line.split("=", 1)[1].strip().strip("()").split(",")
            acc, macro = float(values[1]), float(values[2])

            robust = outputs / f"robust_{mode}_seed{seed}" / "metrics.tsv"
            if robust.exists():
                with robust.open(encoding="utf-8") as f:
                    rows = list(csv.DictReader(f, delimiter="\t"))
                if len(rows) != 15:
                    failures.append(f"{name}: robust conditions={len(rows)} != 15")
                clean = next(r for r in rows if r["condition"] == "clean")
                if abs(float(clean["accuracy"]) - acc) > 1e-9 or \
                   abs(float(clean["macro_f1"]) - macro) > 1e-9:
                    failures.append(
                        f"{name}: clean row {clean['accuracy']}/{clean['macro_f1']} "
                        f"!= metrics.txt {acc}/{macro}")
                if int(clean["n"]) != 619:
                    failures.append(f"{name}: robust n={clean['n']} != 619")
            checked += 1

    print(f"checked {checked} main directories")
    if failures:
        print(f"{len(failures)} problems:")
        for item in failures:
            print("  " + item)
        raise SystemExit(1)
    print("all acceptance checks PASS")


if __name__ == "__main__":
    main()
