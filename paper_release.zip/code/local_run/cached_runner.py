"""Run the original training / robustness scripts with cached RGB frames.

The original scripts are imported unmodified; only their ``MultiDataset`` is
swapped for the cache-backed equivalent, so every hyper-parameter, the model,
the loss, the modality dropout, the checkpoint selection rule and the
corruption suite stay exactly as defined in the three-person manual.
"""

from __future__ import annotations

import argparse
import importlib
import sys
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--job", choices=["train", "robust"], required=True)
    ap.add_argument("--cache-dir", required=True)
    known, rest = ap.parse_known_args()

    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(Path(__file__).resolve().parent))

    import cached_data
    cached_data.install(known.cache_dir)

    module = importlib.import_module(
        "run_multimodal_baseline" if known.job == "train" else "robust_eval")
    sys.argv = [module.__file__] + rest
    module.main()


if __name__ == "__main__":
    main()
