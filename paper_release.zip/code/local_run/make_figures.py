"""Build the paper figures required by section 8 of the three-person manual."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

MODES = ["rgb", "pose", "sum", "concat", "ours", "fixed"]
COLORS = {"sum": "#4C72B0", "ours": "#C44E52", "fixed": "#55A868",
          "concat": "#8172B2"}
CLASSES = ["dribble", "layup", "shoot"]


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def as_float(value, default=float("nan")) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def main_figure(rows: list[dict], out_dir: Path) -> None:
    modes = [m for m in MODES if any(r["mode"] == m for r in rows)]
    acc = [as_float(next(r for r in rows if r["mode"] == m)["accuracy_mean"]) for m in modes]
    acc_std = [as_float(next(r for r in rows if r["mode"] == m)["accuracy_std"], 0.0) for m in modes]
    f1 = [as_float(next(r for r in rows if r["mode"] == m)["macro_f1_mean"]) for m in modes]
    f1_std = [as_float(next(r for r in rows if r["mode"] == m)["macro_f1_std"], 0.0) for m in modes]

    x = np.arange(len(modes))
    width = 0.38
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar(x - width / 2, acc, width, yerr=acc_std, capsize=4,
           label="Accuracy", color="#4C72B0")
    ax.bar(x + width / 2, f1, width, yerr=f1_std, capsize=4,
           label="Macro-F1", color="#DD8452")
    ax.set_xticks(x, modes)
    ax.set_ylim(0, 1)
    ax.set_ylabel("score")
    ax.set_title("Henu-MultiSubjects: RGB / RGB-derived pose fusion (mean of 3 seeds)")
    ax.grid(axis="y", alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_dir / "fig_main_models.png", dpi=200)
    plt.close(fig)


def curve_figure(rows: list[dict], out_dir: Path, title: str, prefix: str,
                 filename: str, xlabel: str, rates: list[float]) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, metric, label in zip(axes, ("accuracy", "macro_f1"), ("Accuracy", "Macro-F1")):
        for mode in ("sum", "ours", "fixed", "concat"):
            conditions = [f"{prefix}{rate:g}" for rate in rates]
            xs, ys, errs = [], [], []
            for condition, rate in zip(conditions, rates):
                match = [r for r in rows if r["mode"] == mode and r["condition"] == condition]
                if not match:
                    continue
                xs.append(rate)
                ys.append(as_float(match[0][f"{metric}_mean"]))
                errs.append(as_float(match[0][f"{metric}_std"], 0.0))
            if not xs:
                continue
            ax.errorbar(xs, ys, yerr=errs, marker="o", capsize=3,
                        color=COLORS.get(mode), label=mode)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(label)
        ax.grid(alpha=0.3)
        ax.legend()
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(out_dir / filename, dpi=200)
    plt.close(fig)


def confusion_figure(report: Path, out_dir: Path) -> None:
    data = json.loads(report.read_text(encoding="utf-8"))
    cm = np.asarray(data["confusion"], dtype=float)
    norm = cm / np.maximum(cm.sum(axis=1, keepdims=True), 1)
    fig, ax = plt.subplots(figsize=(4.6, 4.2))
    im = ax.imshow(norm, cmap="Blues", vmin=0, vmax=1)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f"{int(cm[i, j])}\n{norm[i, j]:.2f}", ha="center",
                    va="center", color="black" if norm[i, j] < 0.6 else "white",
                    fontsize=9)
    ax.set_xticks(range(3), CLASSES)
    ax.set_yticks(range(3), CLASSES)
    ax.set_xlabel("predicted")
    ax.set_ylabel("true")
    ax.set_title(f"Ours (clean test, seed {data.get('seed', '')})")
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(out_dir / "fig_confusion_ours_clean.png", dpi=200)
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    args = ap.parse_args()
    reports = args.root / "reports"
    figures = reports / "figures"
    figures.mkdir(parents=True, exist_ok=True)

    main_path = reports / "main_summary.csv"
    robust_path = reports / "robust_summary.csv"
    if main_path.exists():
        main_figure(read_csv(main_path), figures)
        print(f"wrote {figures / 'fig_main_models.png'}")
    if robust_path.exists():
        rows = read_csv(robust_path)
        curve_figure(rows, figures, "RGB modality missing",
                     "missing_rgb_", "fig_missing_rgb.png", "missing rate",
                     [0.2, 0.4, 0.6, 1.0])
        curve_figure(rows, figures, "Pose modality missing",
                     "missing_pose_", "fig_missing_pose.png", "missing rate",
                     [0.2, 0.4, 0.6, 1.0])
        curve_figure(rows, figures, "RGB Gaussian noise",
                     "rgb_gaussian_", "fig_rgb_noise.png", "sigma",
                     [0.02, 0.05, 0.10])
        curve_figure(rows, figures, "Pose coordinate jitter",
                     "pose_jitter_", "fig_pose_jitter.png", "jitter",
                     [0.01, 0.03, 0.05])
        print(f"wrote robustness curves to {figures}")
    confusion = args.root / "reports" / "confusion_ours_clean" / "confusion.json"
    if confusion.exists():
        confusion_figure(confusion, figures)
        print(f"wrote {figures / 'fig_confusion_ours_clean.png'}")


if __name__ == "__main__":
    main()
