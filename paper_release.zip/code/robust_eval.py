"""Deterministic robustness evaluation for a trained Henu RGB/Pose model.

This script never updates model weights. It applies the same test corruption
suite to every checkpoint and writes one row per condition to metrics.tsv.
The modality masks are per-video (not per-frame) and are deterministic from
the video name, so different models see exactly the same test cases.
"""

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader

from run_multimodal_baseline import MultiDataset, FusionModel, scores, seed_all


MEAN = torch.tensor([0.485, 0.456, 0.406], dtype=torch.float32)
STD = torch.tensor([0.229, 0.224, 0.225], dtype=torch.float32)


def stable_u01(text):
    """Return a platform-independent pseudo-random number in [0, 1)."""
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "little") / float(2**64)


def make_availability(videos, missing, rate):
    avail = torch.ones((len(videos), 2), dtype=torch.float32)
    if missing == "none" or rate <= 0:
        return avail
    for i, video in enumerate(videos):
        # The same video is either missing or present for the whole modality.
        if stable_u01(f"henu-mask-v1|{missing}|{video}") < rate:
            avail[i, 0 if missing == "rgb" else 1] = 0.0
    return avail


def apply_noise(rgb, pose, noise, level, generator):
    if noise == "rgb_gaussian":
        # Noise levels are defined in the unnormalised [0, 1] image domain.
        mean = MEAN.to(rgb.device).view(1, 1, 3, 1, 1)
        std = STD.to(rgb.device).view(1, 1, 3, 1, 1)
        raw = (rgb * std + mean).clamp(0.0, 1.0)
        raw = (raw + torch.randn(raw.shape, device=rgb.device,
                                 generator=generator) * level).clamp(0.0, 1.0)
        rgb = (raw - mean) / std
    elif noise == "pose_jitter":
        pose = pose + torch.randn(pose.shape, device=pose.device,
                                  generator=generator) * level
    return rgb, pose


def condition_name(missing, rate, noise, level):
    if noise != "none":
        return f"{noise}_{level:g}"
    if missing == "none":
        return "clean"
    return f"missing_{missing}_{rate:g}"


@torch.no_grad()
def evaluate(model, loader, device, criterion, missing, rate, noise, level,
             noise_seed):
    model.eval()
    ys, ps, total = [], [], 0.0
    generator = torch.Generator(device=device)
    generator.manual_seed(int(noise_seed))
    with torch.inference_mode():
        for rgb, pose, quality, y, videos in loader:
            rgb = rgb.to(device, non_blocking=True)
            pose = pose.to(device, non_blocking=True)
            quality = quality.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)
            avail = make_availability(videos, missing, rate).to(device)
            rgb = rgb * avail[:, 0, None, None, None, None]
            pose = pose * avail[:, 1, None, None]
            rgb, pose = apply_noise(rgb, pose, noise, level, generator)
            logits = model(rgb, pose, quality, avail)
            loss = criterion(logits, y)
            total += float(loss.item()) * len(y)
            ys.extend(y.cpu().numpy().tolist())
            ps.extend(logits.argmax(1).cpu().numpy().tolist())
    acc, macro, f1 = scores(ys, ps)
    return {
        "loss": total / max(len(ys), 1),
        "accuracy": acc,
        "macro_f1": macro,
        "f1_dribble": f1[0],
        "f1_layup": f1[1],
        "f1_shoot": f1[2],
        "n": len(ys),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--pose-root", required=True)
    ap.add_argument("--mode", required=True,
                    choices=["rgb", "pose", "sum", "concat", "transformer",
                             "ours", "fixed"])
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--frames", type=int, default=8)
    ap.add_argument("--pose-frames", type=int, default=16)
    ap.add_argument("--size", type=int, default=64)
    ap.add_argument("--limit", type=int, default=0,
                    help="Diagnostic subset only; keep 0 for reported results")
    ap.add_argument("--workers", type=int, default=0,
                    help="Use 0 for reproducible test ordering")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--fixed-alpha", type=float, default=0.5,
                    help="constant RGB weight of the fixed-fusion baseline")
    args = ap.parse_args()

    seed_all(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_rgb = args.mode != "pose"
    tr = MultiDataset(args.manifest, args.pose_root, "train", args.frames,
                      args.pose_frames, args.size, False, args.limit, use_rgb)
    te = MultiDataset(args.manifest, args.pose_root, "test", args.frames,
                      args.pose_frames, args.size, False, args.limit, use_rgb)
    loader = DataLoader(te, batch_size=args.batch_size, shuffle=False,
                        num_workers=args.workers, pin_memory=(device.type == "cuda"))
    counts = np.bincount([int(r["label"]) for r in tr.rows], minlength=3)
    weights = torch.tensor(counts.sum() / np.maximum(counts, 1), dtype=torch.float32)
    weights /= weights.mean()
    criterion = nn.CrossEntropyLoss(weight=weights.to(device))
    model = FusionModel(args.mode, fixed_alpha=args.fixed_alpha).to(device)
    state = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(state["model"] if "model" in state else state)
    model.eval()

    conditions = [("none", 0.0, "none", 0.0)]
    for modality in ("rgb", "pose"):
        for rate in (0.20, 0.40, 0.60, 1.00):
            conditions.append((modality, rate, "none", 0.0))
    for level in (0.02, 0.05, 0.10):
        conditions.append(("none", 0.0, "rgb_gaussian", level))
    for level in (0.01, 0.03, 0.05):
        conditions.append(("none", 0.0, "pose_jitter", level))

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    clean_acc = clean_f1 = None
    for missing, rate, noise, level in conditions:
        # Reset the generator for each condition so all checkpoints use the
        # exact same noise tensor sequence for that condition.
        result = evaluate(model, loader, device, criterion, missing, rate,
                          noise, level, args.seed + 7919)
        name = condition_name(missing, rate, noise, level)
        if name == "clean":
            clean_acc, clean_f1 = result["accuracy"], result["macro_f1"]
        result.update({
            "mode": args.mode,
            "condition": name,
            "missing_modality": missing,
            "missing_rate": rate,
            "noise_type": noise,
            "noise_level": level,
            "delta_accuracy": result["accuracy"] - clean_acc if clean_acc is not None else "",
            "delta_macro_f1": result["macro_f1"] - clean_f1 if clean_f1 is not None else "",
        })
        rows.append(result)
        print(json.dumps(result, ensure_ascii=False), flush=True)

    fields = ["mode", "condition", "missing_modality", "missing_rate",
              "noise_type", "noise_level", "loss", "accuracy", "macro_f1",
              "f1_dribble", "f1_layup", "f1_shoot", "delta_accuracy",
              "delta_macro_f1", "n"]
    with (out / "metrics.tsv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)
    (out / "config.json").write_text(json.dumps(vars(args), indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
