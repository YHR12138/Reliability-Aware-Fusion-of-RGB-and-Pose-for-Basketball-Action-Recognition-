# Train every missing final_<mode>_seed<seed> directory with the cached loader.
#
#   ./code/scripts/run_training.ps1 -Modes @('ours') -Seeds @(2026) -ForceRerun
#
param(
    [string]$Root = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)),
    [string]$CacheDir = '',
    [string]$Python = 'python',
    [string[]]$Modes = @('rgb', 'pose', 'sum', 'concat', 'ours', 'fixed'),
    [int[]]$Seeds = @(2026, 2027, 2028, 2029, 2030),
    [double]$FixedAlpha = 0.34,
    [switch]$ForceRerun
)
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($CacheDir)) { $CacheDir = Join-Path $Root 'cache' }
$Runner = Join-Path $Root 'code\local_run\cached_runner.py'
$Manifest = Join-Path $Root 'manifests\manifest_local.csv'
$PoseRoot = Join-Path $Root 'pose_data'
$OutputRoot = Join-Path $Root 'outputs'
$BatchLog = Join-Path $OutputRoot 'local_batch.log'
New-Item -ItemType Directory -Force -Path $OutputRoot | Out-Null

"[$(Get-Date -Format s)] training batch started" | Tee-Object -FilePath $BatchLog -Append
foreach ($mode in $Modes) {
    foreach ($seed in $Seeds) {
        $out = Join-Path $OutputRoot ("final_{0}_seed{1}" -f $mode, $seed)
        $best = Join-Path $out 'best.pt'
        $metrics = Join-Path $out 'metrics.txt'
        New-Item -ItemType Directory -Force -Path $out | Out-Null
        if (!$ForceRerun -and (Test-Path $best) -and (Test-Path $metrics)) {
            "[$(Get-Date -Format s)] SKIP $mode seed=$seed (already trained)" |
                Tee-Object -FilePath $BatchLog -Append
            continue
        }
        "[$(Get-Date -Format s)] START $mode seed=$seed" |
            Tee-Object -FilePath $BatchLog -Append
        $started = Get-Date
        & $Python $Runner --job train --cache-dir $CacheDir `
            --manifest $Manifest --pose-root $PoseRoot --mode $mode --out $out `
            --epochs 10 --batch-size 8 --frames 8 --pose-frames 16 --size 64 `
            --workers 0 --limit 0 --seed $seed --fixed-alpha $FixedAlpha 2>&1 |
            Tee-Object -FilePath (Join-Path $out 'console.log')
        if ($LASTEXITCODE -ne 0) { throw "Training failed: $mode seed=$seed" }
        $mins = [math]::Round(((Get-Date) - $started).TotalMinutes, 1)
        "[$(Get-Date -Format s)] DONE $mode seed=$seed in ${mins}min" |
            Tee-Object -FilePath $BatchLog -Append
    }
}
"[$(Get-Date -Format s)] training batch completed" |
    Tee-Object -FilePath $BatchLog -Append
