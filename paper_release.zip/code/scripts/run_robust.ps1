# Robustness evaluation of the validated checkpoints (15 conditions each).
#
#   ./code/scripts/run_robust.ps1 -Modes @('ours') -Seeds @(2026) -ForceRerun
#
param(
    [string]$Root = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)),
    [string]$CacheDir = '',
    [string]$Python = 'python',
    [string[]]$Modes = @('ours', 'sum', 'fixed', 'concat'),
    [int[]]$Seeds = @(2026, 2027, 2028, 2029, 2030),
    [double]$FixedAlpha = 0.34,
    [switch]$ForceRerun
)
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($CacheDir)) { $CacheDir = Join-Path $Root 'cache' }
$Runner = Join-Path $Root 'code\local_run\cached_runner.py'
$Manifest = Join-Path $Root 'manifests\manifest_local.csv'
$PoseRoot = Join-Path $Root 'pose_data'
$OutputRoot = Join-Path $Root 'outputs'
$Log = Join-Path $OutputRoot 'local_robust.log'
New-Item -ItemType Directory -Force -Path $OutputRoot | Out-Null

"[$(Get-Date -Format s)] robustness batch started" |
    Tee-Object -FilePath $Log -Append
foreach ($mode in $Modes) {
    foreach ($seed in $Seeds) {
        $ckpt = Join-Path $OutputRoot ("final_{0}_seed{1}\best.pt" -f $mode, $seed)
        $out = Join-Path $OutputRoot ("robust_{0}_seed{1}" -f $mode, $seed)
        $tsv = Join-Path $out 'metrics.tsv'
        if (!(Test-Path $ckpt)) { throw "Missing checkpoint: $ckpt" }
        New-Item -ItemType Directory -Force -Path $out | Out-Null
        if (!$ForceRerun -and (Test-Path $tsv)) {
            "[$(Get-Date -Format s)] SKIP $mode seed=$seed (metrics.tsv exists)" |
                Tee-Object -FilePath $Log -Append
            continue
        }
        "[$(Get-Date -Format s)] START $mode seed=$seed" |
            Tee-Object -FilePath $Log -Append
        $started = Get-Date
        & $Python $Runner --job robust --cache-dir $CacheDir `
            --manifest $Manifest --pose-root $PoseRoot --mode $mode `
            --checkpoint $ckpt --out $out --batch-size 8 --frames 8 `
            --pose-frames 16 --size 64 --workers 0 --limit 0 --seed $seed `
            --fixed-alpha $FixedAlpha 2>&1 |
            Tee-Object -FilePath (Join-Path $out 'console.log')
        if ($LASTEXITCODE -ne 0) { throw "Robustness failed: $mode seed=$seed" }
        $mins = [math]::Round(((Get-Date) - $started).TotalMinutes, 1)
        "[$(Get-Date -Format s)] DONE $mode seed=$seed in ${mins}min" |
            Tee-Object -FilePath $Log -Append
    }
}
"[$(Get-Date -Format s)] robustness batch completed" |
    Tee-Object -FilePath $Log -Append
