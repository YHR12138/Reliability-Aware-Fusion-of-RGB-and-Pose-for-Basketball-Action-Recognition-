"""Build a subject-disjoint manifest for Henu-MultiSubjects.

The official Henu split contains identity overlap.  This script scans every
video, infers the subject from ``<subject>_<label>_<index>.mp4`` and creates a
new deterministic subject-disjoint train/val/test split.  It does not move or
modify any source data.

Example (PowerShell):
    python emergency_iccip/make_manifest.py `
      --video-root D:\\Henu-MultiSubjects\\data\\MultiSubjects_train_val_test `
      --pose-root D:\\Henu-MultiSubjects\\data\\key_points_csv `
      --out emergency_iccip\\henu_subject_disjoint.csv
"""

from __future__ import annotations

import argparse
import random
import re
from pathlib import Path

import numpy as np
import pandas as pd


NAME_RE = re.compile(r"^(?P<subject>\d+)_(?P<label>[dps])_(?P<index>\d+)\.mp4$", re.I)
LABELS = {"d": 0, "p": 1, "s": 2}
LABEL_NAMES = {0: "dribble", 1: "layup", 2: "shoot"}


def infer_video_rows(video_root: Path) -> list[dict]:
    """Scan recursively and keep one path per video basename."""
    found: dict[str, Path] = {}
    for path in video_root.rglob("*.mp4"):
        m = NAME_RE.match(path.name)
        if m is None:
            continue
        # A basename is the dataset's sample id.  If an official split copy
        # exists more than once, prefer the first deterministic path.
        found.setdefault(path.name.lower(), path.resolve())
    rows: list[dict] = []
    for key, path in sorted(found.items()):
        m = NAME_RE.match(path.name)
        assert m is not None
        label = LABELS[m.group("label").lower()]
        rows.append(
            {
                "sample_id": path.stem,
                "video_path": str(path),
                "subject": int(m.group("subject")),
                "label": label,
                "label_name": LABEL_NAMES[label],
            }
        )
    return rows


def assign_subjects(rows: list[dict], seed: int, train_frac: float, val_frac: float) -> dict[int, str]:
    """Greedily assign subjects while approximately balancing class counts.

    Subject disjointness is the hard constraint.  The greedy objective keeps
    split sizes and class proportions close without requiring sklearn.
    """
    subjects = sorted({r["subject"] for r in rows})
    rng = random.Random(seed)
    rng.shuffle(subjects)
    by_subject: dict[int, np.ndarray] = {}
    for sid in subjects:
        c = np.zeros(3, dtype=np.float64)
        for r in rows:
            if r["subject"] == sid:
                c[r["label"]] += 1
        by_subject[sid] = c

    n = len(subjects)
    target_n = {"train": train_frac * n, "val": val_frac * n, "test": (1 - train_frac - val_frac) * n}
    total = np.sum(np.stack(list(by_subject.values())), axis=0)
    target_c = {k: total * (v / n) for k, v in target_n.items()}
    current_n = {k: 0 for k in target_n}
    current_c = {k: np.zeros(3, dtype=np.float64) for k in target_n}

    # Assign subjects with many samples first; this avoids one split receiving
    # almost all of a rare class.
    subjects.sort(key=lambda s: (-float(by_subject[s].sum()), s))
    assignment: dict[int, str] = {}
    for sid in subjects:
        counts = by_subject[sid]
        scores: dict[str, float] = {}
        for split in ("train", "val", "test"):
            nn = current_n[split] + 1
            cc = current_c[split] + counts
            size_penalty = abs(nn - target_n[split]) / max(1.0, target_n[split])
            class_penalty = float(np.abs(cc - target_c[split]).sum() / max(1.0, total.sum()))
            # Slightly favor train when all objectives tie, while respecting
            # the requested proportions.
            tie = {"train": 0.0, "val": 1e-8, "test": 2e-8}[split]
            scores[split] = size_penalty + class_penalty + tie
        split = min(scores, key=scores.get)
        assignment[sid] = split
        current_n[split] += 1
        current_c[split] += counts
    return assignment


def pose_map(pose_root: Path | None) -> dict[str, Path]:
    if pose_root is None or not pose_root.exists():
        return {}
    result: dict[str, Path] = {}
    for suffix in ("*.csv", "*.npy", "*.npz"):
        for p in pose_root.rglob(suffix):
            result.setdefault(p.stem.lower(), p.resolve())
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--video-root", type=Path, required=True)
    ap.add_argument("--pose-root", type=Path, default=None)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--train-frac", type=float, default=0.70)
    ap.add_argument("--val-frac", type=float, default=0.15)
    ap.add_argument("--limit-per-split", type=int, default=0, help="Optional smoke-test cap; 0 keeps all samples")
    args = ap.parse_args()
    if not (0 < args.train_frac < 1 and 0 < args.val_frac < 1 and args.train_frac + args.val_frac < 1):
        raise SystemExit("train/val fractions must be positive and sum to less than one")
    if not args.video_root.exists():
        raise SystemExit(f"video root does not exist: {args.video_root}")

    rows = infer_video_rows(args.video_root)
    if not rows:
        raise SystemExit("No files matching <subject>_<d|p|s>_<index>.mp4 were found")
    assignment = assign_subjects(rows, args.seed, args.train_frac, args.val_frac)
    pmap = pose_map(args.pose_root)
    for r in rows:
        r["split"] = assignment[r["subject"]]
        p = pmap.get(r["sample_id"].lower())
        r["pose_path"] = str(p) if p else ""
        r["pose_available"] = int(p is not None)

    out_rows: list[dict] = []
    for split in ("train", "val", "test"):
        part = [r for r in rows if r["split"] == split]
        if args.limit_per_split:
            # Deterministic cap, retaining a roughly class-balanced prefix.
            rng = random.Random(args.seed + (0 if split == "train" else 1 if split == "val" else 2))
            rng.shuffle(part)
            part = sorted(part[: args.limit_per_split], key=lambda x: x["sample_id"])
        out_rows.extend(part)
    df = pd.DataFrame(out_rows).sort_values(["split", "subject", "sample_id"])
    args.out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out, index=False)

    print(f"wrote {len(df):,} samples / {df.subject.nunique():,} subjects to {args.out}")
    print(df.groupby(["split", "label_name"], observed=False).size().unstack(fill_value=0).to_string())
    overlap = []
    sets = {s: set(df.loc[df.split == s, "subject"]) for s in ("train", "val", "test")}
    for a, b in (("train", "val"), ("train", "test"), ("val", "test")):
        overlap.append(f"{a}/{b}={len(sets[a] & sets[b])}")
    print("subject overlap: " + ", ".join(overlap))
    print(f"pose paths found: {int(df.pose_available.sum()):,}/{len(df):,}")


if __name__ == "__main__":
    main()
