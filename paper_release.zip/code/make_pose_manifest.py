import csv
import pickle
import random
from collections import Counter, defaultdict
from pathlib import Path


POSE_ROOT = Path(r"C:\Users\yhr\Documents\ChatGPT\篮球\emergency_iccip\pose_data")
VIDEO_ROOT = Path(r"D:\Henu-MultiSubjects\data\Subjects1000\subjects1000")
OUT = Path(r"C:\Users\yhr\Documents\ChatGPT\篮球\emergency_iccip\manifest_pose_subject_disjoint.csv")


def assign(groups, seed=2026):
    rng = random.Random(seed)
    subjects = list(groups)
    rng.shuffle(subjects)
    subjects.sort(key=lambda s: len(groups[s]), reverse=True)
    target = {"train": 0.70, "val": 0.15, "test": 0.15}
    totals = len(subjects)
    counts = Counter()
    out = {}
    for sid in subjects:
        split = min(("train", "val", "test"), key=lambda x: counts[x] / max(target[x] * totals, 1))
        out[sid] = split
        counts[split] += 1
    return out


def main():
    records = []
    for name in ("train.pkl", "val.pkl"):
        with open(POSE_ROOT / name, "rb") as f:
            for item in pickle.load(f):
                frame_dir = str(item["frame_dir"])
                parts = frame_dir.split("_")
                if len(parts) != 3 or parts[1] not in {"d", "p", "s"}:
                    continue
                sid = int(parts[0])
                label = {"d": 0, "p": 1, "s": 2}[parts[1]]
                video = f"{frame_dir}.mp4"
                path = VIDEO_ROOT / str(sid) / parts[1] / video
                if not path.exists():
                    raise FileNotFoundError(path)
                records.append({"video": video, "path": str(path), "subject": sid,
                                "label_name": parts[1], "label": label,
                                "trial": int(parts[2]), "pose_file": name,
                                "frame_dir": frame_dir})
    unique = {r["frame_dir"]: r for r in records}
    records = list(unique.values())
    groups = defaultdict(list)
    for r in records:
        groups[r["subject"]].append(r)
    assignment = assign(groups)
    for r in records:
        r["split"] = assignment[r["subject"]]
    fields = ["video", "path", "subject", "label_name", "label", "trial", "pose_file", "frame_dir", "split"]
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(sorted(records, key=lambda r: (r["split"], r["subject"], r["video"])))
    print("videos", len(records), "subjects", len(groups))
    for split in ("train", "val", "test"):
        subset = [r for r in records if r["split"] == split]
        print(split, "videos", len(subset), "subjects", len({r["subject"] for r in subset}),
              "classes", dict(Counter(r["label_name"] for r in subset)))
    print(OUT)


if __name__ == "__main__":
    main()
